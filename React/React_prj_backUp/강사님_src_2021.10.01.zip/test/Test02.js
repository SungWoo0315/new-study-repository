import React, { useState } from 'react';

//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function Test02() {
	//alert( "전수안씨가 어제께 백신 맞고 안좋은 일이 생길꺼라고 저주 했습니다" )
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 number, setNumber 선언하기
	// number 에는 0 저장하고, setNumber 에는 number 지역변수 안의 데이터 갱신하는 익명함수 저장하기
	// 이후부터 setNumber(데이터) 라는 코딩이 실행되면, number 변수안의 데이터가 갱싱되고 
	// 이 함수 컴포넌트가 재 호출된다. 
	// 재 호출 시 아래 코딩은 실행에서 제외된다.
	// number 변수가 마치 클래스 컴포넌트의 state 속성변수의 성격을 가진다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [number, setNumber] = useState(0);

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 add 에 화살표 함수 저장하기
	// 버튼 클릭할 때 실행할 구문을 내포하고 있다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const add = ()=>{
		setNumber(number+1);
	} 
	return (
			<>
				<center>
					{/* 지역변수 number 안의 데이터를 div 태그 사이에 표현하기*/}
					<div>{number}</div>
					{/* 버튼 출력하고 버튼을 클릭하면 add 라는 속성변수 안의 화살표 함수 호출하기*/}
					<button 
						onClick={add}
					>
						+1
					</button>
				</center>
			</>
	)
}
export default Test02;
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명/node_modules/react 안에서 default 가 붙어 수출하는 놈을 수입해서 현재 파일에서 변수 React 에 저장하기
// 프로젝트명/node_modules/react 안안에서에 default 가 안붙어 수출하는 useState 함수를 수입해서 현재 파일에서 변수 useState 에 저장하기
// <참고>함수 컴포넌트를 선언할 할 경우 대부분 useState 함수를 사용한다.
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { Component } from 'react';

//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [클래스 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class RegData2 extends Component {

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 속성변수 nameRef 선언하고 
	// React 객체의  createRef() 메소드를 호출하여 리턴된 데이터를 저장하기.
	// 이후 부터 ref={this.nameRef} 가진 태그는 
	// this.nameRef.current.focus(); 코딩이 실행되면
	// 포커스가 그 태그안으로 들어간다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	nameRef = React.createRef();

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 속성변수 names 선언하고 Array 객체 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	names=[
			{ id: 1, text :'사오정'}
			,{ id: 2, text: '저팔계' }
			,{ id: 3, text: '손오공' }
			,{ id: 4, text: '삼장법사' }
	];
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 리액트가 제공하는 state 속성변수 선언하고 [사용정 객체]를 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		//-----------------------------------------------
		// 클래스 컴포넌트 안에서 리액트가 제공하는 state 속성변수 특징
		//-----------------------------------------------
			// state 속성변수의 갱신은 리액트가 제공하는 setState 메소드 호출로만 가능하다.
			// setState 메소드 호출로 state 속성변수 안의 값이 갱신 되면 rende 메소드가 재 호출된다.
			// state 속성변수 호출할 경우 this. 을 붙인다.
		//-----------------------------------------------
	state = {
		names:this.names             // 이름 목록 저장
		,inputText:""                // 입력 데이터 저장
		,nextId:this.names.length+1  // 추가 저장될 데이터의 고유값
	};

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 화살표함수가 저장된 속성변수 textChange 선언.
	// 아래 매개변수 e 에는 Event 객체가 들어온다.
	// 즉 아래 화살표함수는 입력 양식에 이벤트가 발생했을 때 실행할 구문을 내포하고 있다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	textChange = (e) => {
		/*
		//--------------------------------------------------
		// 지역변수 value 선언하고 이벤트가 발생한 놈의 value 값을 저장하기
		// 앞뒤 공백 제거하고 재 저장하기
		//--------------------------------------------------
		let val= e.target.value;
		val = val.trim();
		//--------------------------------------------------
		// setState 라는 메소드 호출하여
		// state 변수 안의 저장된 사용정 객체 안의 속성변수 inputText 안의 데이터를
		// val 안의 데이터로 갱신하라
		//--------------------------------------------------
		// <주의>state 변수 안의 저장된 사용정 객체가 
		//       {inputText:val } 로 완전 갱신 된게 절대 아니다.
		//       즉 부분 갱신만 진행된 것이다.
		//--------------------------------------------------
		this.setState( 
			{inputText:val }
		); 
		*/
		//--------------------------------------------------
		// setState 라는 메소드 호출하여
		// state 변수 안의 저장된 사용정 객체 안의 속성변수 inputText 안의 데이터를
		// val 안의 데이터로 갱신하라
		//--------------------------------------------------
		// <주의>state 변수 안의 저장된 사용정 객체가 
		//       {inputText:val } 로 완전 갱신 된게 절대 아니다.
		//       즉 부분 갱신만 진행된 것이다.
		//--------------------------------------------------
		this.setState( 
			{inputText:e.target.value }
		); 
	}

	keyPress = e => {
		if (e.key === 'Enter') {
			this.add( );
		}
	}

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 화살표함수가 저장된 지역변수 add 선언.
	// 화살표함수 안에는 추가 버튼 클릭 시 호출되는 실행 구문을 내포하고 있다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	add = () => {
		//-----------------------------------------------
		// 3개의 지역변수 선언하고 state 속성변수 안의 사용정 객체 안의 데이터를 지역변수에 저장하기
		// <주의> 지역변수에 inputText는 공백 제거 예정이므로 변수 왼쪽에 const 를 사용하지 않는다.
		//-----------------------------------------------
		let inputText = this.state.inputText;
		const nextId = this.state.nextId;
		const names = this.state.names;
		//-----------------------------------------------
		// 만약 입력한 데이터가 비어있으면 경고하고 함수 중단.
		//-----------------------------------------------
		if( inputText==null || inputText==undefined || inputText.split(" ").join("")=="" ){
			alert("데이터가 비어 있어 입력이 불가능!");
			this.setState(   {inputText: ''}  ); 
			this.nameRef.current.focus();
			return;
		}
		inputText = inputText.trim();
		//-----------------------------------------------
		// 만약 중복되어 있으면 경고하고 함수 중단.
		//-----------------------------------------------
		if( names!=null ){
			//--------------------------------------
			// 지역변수 tmpNames 선언하고 
			// Array 객체의 filter 메소드를 호출하여
			// names 에 저장된 사용정객체를 1개씩 꺼내서
			// 아래의 화살표 함수를 호출하여 리턴되는 데이더가 true 일때만 
			// 사용자정의 객체 만 복사해 누적하기
			//--------------------------------------
			const tmpNames = names.filter(  (name)=>name.text===inputText   );
			if( tmpNames.length>0  ){
				alert( inputText + " 문자는 이미있어 입력이 불가능!");
				this.setState(   {inputText: ''}  ); 			
				this.nameRef.current.focus();
				return;
			}
		}
		//---이 프로그램의 키포인트 소스-----------------
		// 지역변수 newNames 선언하고
		// names 안의 Array 객체 복사하고 {id: nextId,text : inputText} 추가하고
		// 이렇게 만들어 새로운 Array 객체를 newNames 저장하기
		//-----------------------------------------------
		const newNames = names.concat({
			id: nextId ,      // nextld 값을 id로 설정하고
			text : inputText
		});
		//-----------------------------------------------
		// newNames 안의 Array 객체를 기존 사용정 객체 안의 names 속성변수에 갱신해서 저장하기
		//-----------------------------------------------
		this.setState(  {names:newNames}  );
		//-----------------------------------------------
		// 사용정 객체 안의 nextId 속성변수에  nextId+1 의 실행 결과 저장하기. 
		// 즉 기존 데이터에서 1 증가하란 의미
		//-----------------------------------------------
		this.setState(  {nextId:nextId+1 }  );
		//-----------------------------------------------
		// 사용정 객체 안의 inputTex 속성변수에  "" 저장하기. 
		// 즉 결국 입력 양식이 비어지게 된다.
		//-----------------------------------------------
		this.setState(   {inputText: ''}  ); 			
		
		this.nameRef.current.focus();

	}

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 화살표함수가 저장된 지역변수 remove 선언.
	// 화살표함수 안에는 목록을 더블클릭하면 목록을 삭제하는 구문이 내포되어 있다.
	// 매개변수 더블클릭하는 목록의 고유값인 id 값이 들어 온다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	remove = (id)=>{
		const names = this.state.names;
		if( names.length==1 ){
			alert("제거 불가능! 최소한 1개는 있어야합니다");
			return;
		}
		//--------------------------------------
		// 지역변수 nextNames 선언하고 
		// Array 객체의 filter 메소드를 호출하여
		// names 에 저장된 사용정객체를 1개씩 꺼내서
		// 아래의 화살표 함수를 호출하여 리턴되는 데이더가 true 일때만 
		// 사용자정의 객체 만 복사해 누적하기
		// 즉 매개변수로 들어온 id 과 같지 않은 놈만 골라서 누적하기
		//--------------------------------------
		const nextNames = names.filter(name=>name.id !==id);
		//--------------------------------------
		// state 속성변수에 저장된 사용정 객체 안의  names 을  nextNames 로 갱신하기. 
		//-----------------------------------------------
		this.setState(  {names:nextNames}  );
	};

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// render 메소드 필수 1개 선언. 
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	render( ) {
		//------------------------------------------------
		// 지역변수 namesTag 선언하고 
		// Array 객체의 map 메소드를 호출하여
		// names 에 저장된 사용정객체를 1개씩 꺼내서
		// 아래의 화살표 함수를 호출하여 리턴되는 html 코딩을 누적해 저장하기
		//------------------------------------------------
		const namesTag = this.state.names.map(
			name =>
				<li style={{cursor:'pointer'}} key={name.id} onDoubleClick={()=>this.remove(name.id)}>
					{name.text}
				</li>
		);
		//------------------------------------------------
		// JSX 문법을 가진 return 구문 선언
		// 리턴되는 JSX 문법이 결국 웹화면에 출력된다.
		//------------------------------------------------
		return (
			<>
				<center>
					<table><tr><td>

					<input 
						type='text' 
						ref={this.nameRef}
					
						onKeyPress={this.keyPress}

						value={this.state.inputText} // value 속성값으로 state 속성변수 안의  inputText 속성변수 안의 데이터를 삽입하기
						onChange={this.textChange}   // 입력값이 바뀌면, 즉 키보드로 데이터를 입력하면 textChange 변수안의 화살표함수 호출하기
					/>&nbsp;
					<button 
						onClick={this.add}           // 버튼 클릭하면 add 변수안의 화살표함수 호출하기
					>
						추가
					</button>

					<ul>{namesTag}</ul>
					</td>
					</tr>
					</table>
			</center>
			</>
		)
	}
}

export default RegData2;

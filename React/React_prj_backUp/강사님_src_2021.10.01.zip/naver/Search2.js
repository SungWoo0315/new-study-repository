//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { Component } from 'react';


//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [클래스 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class Search2 extends Component {

	keywordRef = React.createRef();

	developerList =	[
			{ dev_no: 1, dev_name :'사오정', addr :'서울시', phone :'010-1111-2222'}
			,{ dev_no: 2, dev_name :'저팔계', addr :'부산시', phone :'010-1234-4545'}
			,{ dev_no: 3, dev_name :'손오공', addr :'광명시', phone :'010-3444-8888'}
	];
	
	state = {
		developers:developerList
		,inputText:''
	}
	textChange = (e) => {
		this.setState( {inputText:e.target.value}  );
	}
	search = () => {
		const developers = this.state.developers;
		const inputText = this.state.inputText;

		const tmp_inputText = inputText.trim();
		this.setState( {inputText:tmp_inputText}  );
		const new_developerList = developerList.filter( 
			developer=>
				developer.dev_name.indexOf(tmp_inputText)>=0
				||developer.addr.indexOf(tmp_inputText)>=0
				||developer.phone.indexOf(tmp_inputText)>=0
		);
		this.setState( {developers:new_developerList}  );
		this.keywordRef.current.focus();
	}
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	searchAll = () => {
		this.setState( {inputText:''}  );
		this.setState( {developers:developerList}  );
		this.keywordRef.current.focus();
	}
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	render( ) {
		const searchResultTag = this.state.developers.map(
				developer =>
					<tr>
						<td>{developer.dev_no}</td>
						<td>{developer.dev_name}</td>
						<td>{developer.addr}</td>
						<td>{developer.phone}</td>
					</tr>
		);
		const inputText = this.state.inputText;
		return (
			<>
			<center><br/>
				[키워드] : &nbsp;
				<input 
					type='text' 
					ref={this.keywordRef}
					value={inputText}   
					onChange={this.textChange} 
				/>&nbsp;
				<button  onClick={this.search}>검색</button>&nbsp;
				<button  onClick={this.searchAll}>모두검색</button>
				<br/><br/>
				검색 개수 : {developers.length}
				<table border="1"  cellpadding="4">
					<tr>
						<th>번호</th>
						<th>직원명</th>
						<th>주소</th>
						<th>전화</th>
					</tr>
					{searchResultTag}
				</table>
				{developers.length==0?'검색결과없음둥.....':''}
			</center>
			</>
		)
	}

}
export default Search2;








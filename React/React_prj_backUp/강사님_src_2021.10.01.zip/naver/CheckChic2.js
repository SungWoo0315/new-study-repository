import React, { Component } from 'react';
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [클래스 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class CheckChic2 extends Component {
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	state = {
		m_number:0
		,w_number:0
	}
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	m_add = ()=>{
		this.setState( {m_number:this.state.m_number+1} );
	} 
	m_minus = ()=>{
		this.setState( {m_number:this.state.m_number-1} );
	} 
	w_add = ()=>{
		this.setState( {w_number:this.state.w_number+1} );
	} 
	w_minus = ()=>{
		this.setState( {w_number:this.state.w_number-1} );
	} 
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	render(){
		const m_number = this.state.m_number;
		const w_number = this.state.w_number;
		return (
			<>
			<center>
				<hr/> 
				총 : {m_number+w_number}  마리
				<hr/>
				숫병아리 : <button  onClick={this.m_add} >+1</button> 
				           <button  onClick={this.m_minus} >-1</button> {m_number} 마리
				<br/>
				암병아리 : <button  onClick={this.w_add} > +1 </button> 
				           <button  onClick={this.w_minus} >-1</button> {w_number} 마리
			</center>
			</>
		)
	}
}
export default CheckChic2;


/*
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function CheckChic() {
	const [m_number, setM_number] = useState(0);
	const [w_number, setW_number] = useState(0);

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 add 에 화살표 함수 저장하기
	// 버튼 클릭할 때 실행할 구문을 내포하고 있다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const m_set = (num)=>{
		setM_number(m_number+num);
	} 
	const w_set = (num)=>{
		setW_number(w_number+num);
	} 
	return (
			<>
				<center>
					<hr/> 
					총 : {m_number+w_number}  마리
					<hr/>
					숫병아리 : <button  onClick={()=>m_set(1)} >+1</button> 
					<button  onClick={()=>m_set(-1)} >-1</button> {m_number} 마리
					<br/>
					암병아리 : <button  onClick={()=>w_set(1)} > +1 </button> 
					<button  onClick={()=>w_set(-1)} >-1</button> {w_number} 마리

				</center>
			</>
	)
}
*/
import React, { Component } from 'react';
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [클래스 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class CheckChic4 extends Component {
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	state = {
		m_number:0
		,w_number:0
	}
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	setNumber = (m_or_w,number)=>{
		const m_number = this.state.m_number;
		const w_number = this.state.w_number;
		// 만약 number 가 음수 이고 숫/암병아리 수가 0 면 경고하고 함수 중단하기
		if( number<0  ){
			if(  m_or_w=='w' && w_number==0 ){
				alert('암병아리가 0개 미만 일수 없습니다.');return;
			}
			else if(  m_or_w=='m' && m_number==0 ){
				alert('숫병아리가 0개 미만 일수 없습니다.');return;
			}
		}
		if( m_or_w=="m" ){
			this.setState(  {m_number:m_number+number}  );
		}
		else if( m_or_w=="w" ){
			this.setState(  {w_number:w_number+number}  );
		}
	} 
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	render(){
		const m_number = this.state.m_number;
		const w_number = this.state.w_number;
		return (
			<>
			<center>
				CheckChic4
				<hr/> 
				총 : {m_number+w_number}  마리
				<hr/>
				숫병아리 : <button  onClick={()=>{this.setNumber('m',1)}} >+1</button> 
						   <button  onClick={()=>{this.setNumber('m',-1)}} >-1</button> 
						   {m_number} 마리
				<br/>
				암병아리 : <button  onClick={()=>{this.setNumber('w',1)}} > +1 </button> 
						   <button  onClick={()=>{this.setNumber('w',-1)}} >-1</button> 
						   {w_number} 마리
			</center>
			</>
		)
	}
}
export default CheckChic4;


/*
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function CheckChic() {
	const [m_number, setM_number] = useState(0);
	const [w_number, setW_number] = useState(0);

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 add 에 화살표 함수 저장하기
	// 버튼 클릭할 때 실행할 구문을 내포하고 있다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const m_set = (num)=>{
		setM_number(m_number+num);
	} 
	const w_set = (num)=>{
		setW_number(w_number+num);
	} 
	return (
			<>
				<center>
					<hr/> 
					총 : {m_number+w_number}  마리
					<hr/>
					숫병아리 : <button  onClick={()=>m_set(1)} >+1</button> 
					<button  onClick={()=>m_set(-1)} >-1</button> {m_number} 마리
					<br/>
					암병아리 : <button  onClick={()=>w_set(1)} > +1 </button> 
					<button  onClick={()=>w_set(-1)} >-1</button> {w_number} 마리

				</center>
			</>
	)
}
*/
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명/node_modules/react 안에서 default 가 붙어 수출하는 놈을 수입해서 현재 파일에서 변수 React 에 저장하기
// 프로젝트명/node_modules/react 안안에서에 default 가 안붙어 수출하는 useState 함수를 수입해서 현재 파일에서 변수 useState 에 저장하기
// <참고>함수 컴포넌트를 선언할 할 경우 대부분 useState 함수를 사용한다.
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { useState} from 'react';

//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 함수 컴포넌트 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
const RegData = () => {
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [names , setNames] = useState( 
		[
			{ id: 1, text :'사오정'}
			,{ id : 2, text: '저팔계' }
			,{ id: 3, text: '손오공' }
			,{ id: 4, text: '삼장법사' }
		]
	);
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [inputText , setInputText] = useState('') ;
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [nextId , setNextId] = useState(names.length+1) ;
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const textChange = (e) => {
		setInputText(e.target.value) ;
	}
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const add = () => {
		// 만약 비어있으면 경고하고 함수 중단.
		// 만약 중복되어 있으면 경고하고 함수 중단.
		const newNames = names.concat({
			id: nextId ,      // nextld 값을 id로 설정하고
			text : inputText
		});
		setNextId( nextId+1 ) ; 
		setNames( newNames ) ; 
	}
	const onRemove = (id)=>{
		// 매개변수로 들어온 id 을 가진 놈을 삭제한 후 재 저장
	};
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const namesTag = names.map(
		name => 
			<li style={{cursor:'pointer'}} key={name.id} onDoubleClick={()=>remove(name.id)}>
				{name.text}
			</li>
	);
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	return (
		<>
		<center>
			<table><tr><td>
			<input type='text' value={inputText} onChange={textChange}/>&nbsp;
			<button onClick={add}>추가</button>
			<ul>{namesTag}</ul>
			</td></tr></table>
		</center>
		</>
	)
};

export default RegData;

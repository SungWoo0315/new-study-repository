import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import Test from './naver/Test' ;

function App() {
  return (
    <div>
      <Route path="/naver/test" component={Test}/>
    </div>
  );
}

export default App;

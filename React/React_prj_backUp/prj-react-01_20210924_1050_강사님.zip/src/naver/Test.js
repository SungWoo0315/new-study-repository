
import React, { Component } from 'react';

const Test = () => {
	return (
		<div>
			내가 만들어써! 다음달 휴강일은 10.4일 10.11일 임다.
		</div>
	);
}

export default Test;
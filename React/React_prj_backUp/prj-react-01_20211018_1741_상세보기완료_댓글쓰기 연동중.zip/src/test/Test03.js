
import React, { useState } from 'react';

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function Test03() {
    // nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
    // 지역변수 names 선언하고 사용정객체 5개가 저장된 Array 객체를 저장하기 
    // nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
    const names = [
        { id : 1, text : '사오정'}
        ,{ id : 2, text : '저팔계'}
        ,{ id : 3, text : '손오공'}
        ,{ id : 4, text : '삼장법사'}
        ,{ id : 5, text : '우마왕'}
    ];
    
    // nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
    // 지역변수 namesTag 선언하고 
    // Array 객체의 map 매소드를 호출하여 
    // names 에 저장된 사용정 객체를 1개씩 꺼내서
    // 아래의 화살표 함수를 호출하여 리턴되는 html 코딩을 누적하기
    // name => <tr><td>{name.id}</td><td>{name.text}</td></tr>
    // nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
    const namesTag = names.map(
        name => 
                <tr key={name.id}>
                    <td>{name.id}</td>
                    <td>{name.text}</td>
                </tr>
    );

    return (
            <>
            <center>
                <table border="1" cellPadding="5" cellspacing="0">
                    <caption>총 {names.length} 명</caption>
                    <th>학생번호</th>
                    <th>학생명</th>
                    {namesTag}
                </table>
            </center>
            </>
    )
}
export default Test03;
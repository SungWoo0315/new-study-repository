import React, {useState, useRef, useEffect} from 'react';
import axios from "axios";

function BoardContentForm(props) {
    
    // 내가 테스트 했을 때 썼던것.
    // let xxx = props.location.state;

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 게시판 검색 화면에서 행 클릭 시 들고온 게시판 고유번호 꺼내기  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const b_no = props.location.state.b_no;   
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // DB 에서 가져온 1개의 게시판 데이터를 저장할 지역변수 board 선언하기  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [board, setBoard] = useState( {} );   
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // DB 에서 1개의 게시판 데이터를 가져올 코딩이 내포된 화살표 함수를 저장할 변수 선언하기  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const getBoard = () => {
        // b_no 값 확인하기.  
        // alert( b_no ); return;

        // ----------------------------------------------------
        // http://localhost:8081/naver/boardContentForm.do 라는 URL 주소로 접속해서 
        // DB 연동 결과물을 얻어와 지역변수 board 에 저장하기   
        // ----------------------------------------------------
        axios.post(
            'http://localhost:8081/naver/boardContentForm.do'   // URL 주소  
            ,{b_no:b_no}                                        // 전송할 데이터
        ).then(
            // 서버의 응답이 성공했을 때 실행할 코딩을 내포한 화살표 함수 선언하기  
            // 화살표 함수의 매개변수로 1개의 게시판 글을 내포한 사용정 객체가 들어온다.  
            // 이 사용정 객체에서 서버의 응답물(=1개의 게시판 글)은 responseJson.data 에 저장되어 있다.  
            responseJson => {
                // 테스트용 
                // alert( responseJson.data.boardDTO.subject + "\n" + responseJson.data.boardDTO.content )
                setBoard( {
                    ...board
                    , ...responseJson.data.boardDTO
                } );
                // alert(responseJson.data.boardListAllCnt)
            }
        ).catch(
            // 서버의 응답이 실패했을 때 실행할 코딩을 내포한 화살표 함수 선언하기
            (error) => {
                alert("서버 연동 실패! : " + error.message);
            }
        )
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    useEffect(
        ()=>{
            getBoard();
        }
        ,[]
    );  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const goBoardUpDelForm = () =>{
        
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const goBoardRegForm = () =>{
        props.history.push({
            pathname : "/board/BoardRegForm"
            ,state : {b_no:board.b_no}
        });
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm


    return(
        <><center>

            <br></br>
            {/* --------------------------------------------------- */}
            {/* 내가 테스트 했을 때 썼던것. */}
            {/* b_no 번호 : {xxx}    <br/> */}

            b_no 번호 : {b_no}  

            <br></br>
            <br></br>

            <table cellPadding='5' cellSpacing='0' bordercolor='lightgray' border='1' style={{borderCollapse:'collapse'}}>
                <caption>상세보기</caption>
                <tr>
                    <th bgcolor='#efefef'>제목</th>
                    <td>{board.subject}</td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>작성자</th>
                    <td>{board.writer}</td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>조회수</th>
                    <td>{board.readcount}</td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>내용</th>
                    <td>    
                        <textarea 
                                name='content'
                                rows='20' cols='50'
                                value ={board.content}
                                readOnly>

                        </textarea>
                    </td>
                </tr>
            </table>
            {/* --------------------------------------------------- */}

            {/* 공백조절 */}
            <div style={{height:'10pt'}}></div>   

            <button onClick={goBoardRegForm}>댓글쓰기</button>{ ' ' }
            <button onClick={goBoardUpDelForm}>수정/삭제</button>{ ' ' }
            <button onClick={()=>{props.history.push('/board/Boardlist');}}>목록보기</button><br></br>
            
        </center></>
    )
}
export default BoardContentForm;

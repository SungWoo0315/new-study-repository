import logo from './logo.svg';
import './App.css';

import React, {Component} from 'react';
import { Route } from 'react-router-dom';
// import Test from './naver/Test';  // 테스트 끝나서 주석처리.


import Counter from './naver/Counter';
import Counter2 from './naver/Counter2';
import Test01 from './test/Test01';
import Test02 from './test/Test02';
import Test03 from './test/Test03';
import CheckChic from './naver/CheckChic';
import CheckChic2 from './naver/CheckChic2';
import CheckChic3 from './naver/CheckChic3';
import CheckChic4 from './naver/CheckChic4';
import RegData from './naver/RegData';
import RegData2 from './naver/RegData2';
import Search from './naver/Search';
import Search_T from './naver/Search_T';
import Search_T2 from './naver/Search_T2';
import Search_T5 from './naver/Search_T5';
import CheckLogin from './naver/CheckLogin';
import LoginForm from './board/LoginForm';
import BoardList from './board/BoardList';
import BoardContentForm from './board/BoardContentForm';


function App() {
  return (
    <div>
      {/* <Route path="/naver/test" component={Test}></Route> */} 
      
      {/* --------------------------------------------  */}
      {/* URL 주소가 ~:3000/naver/Counter 일 경우 Counter 컴포넌트 호출해라  */}
      {/* --------------------------------------------  */}
      <Route path="/naver/Counter" component={Counter}></Route>

      {/* --------------------------------------------  */}
      {/* URL 주소가 ~:3000/naver/Counter2 일 경우 Counter2 컴포넌트 호출해라  */}
      {/* --------------------------------------------  */}
      <Route path="/naver/Counter2" component={Counter2}></Route>
      
      <Route path="/test/Test01" component={Test01}></Route>
      <Route path="/test/Test02" component={Test02}></Route>
      <Route path="/test/Test03" component={Test03}></Route>
      <Route path="/naver/CheckChic" component={CheckChic}></Route>
      <Route path="/naver/CheckChic2" component={CheckChic2}></Route>
      <Route path="/naver/CheckChic3" component={CheckChic3}></Route>
      <Route path="/naver/CheckChic4" component={CheckChic4}></Route>
      <Route path="/naver/RegData" component={RegData}></Route>
      <Route path="/naver/RegData2" component={RegData2}></Route>
      <Route path="/naver/Search" component={Search}></Route>
      <Route path="/naver/Search_T" component={Search_T}></Route>
      <Route path="/naver/Search_T2" component={Search_T2}></Route>
      <Route path="/naver/Search_T5" component={Search_T5}></Route>
      <Route path="/naver/CheckLogin" component={CheckLogin}></Route>
      <Route path="/board/LoginForm" component={LoginForm}></Route>
      <Route path="/board/BoardList" component={BoardList}></Route>
      <Route path="/board/BoardContentForm" component={BoardContentForm}></Route>
    </div>







    // <>
    // <div className="App">
    //   <header className="App-header">

    //   {/* --------------------------------------------  */}
    //   {/* 주석처리 */}
    //   {/* --------------------------------------------  */}
    //   안녕하세요 React 입니다!....<br/>
    //   하하하하핳...
    //   hahaha<br/>
    //   겨우 들어왔다...
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // <div>

    // </div>  
    // </div>
    // </>
  );
}

export default App;

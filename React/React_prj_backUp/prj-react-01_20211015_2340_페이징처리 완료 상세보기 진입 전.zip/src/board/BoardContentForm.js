import React, {useState, useRef, useEffect} from 'react';
import axios from "axios";

function BoardContentForm(props) {
    
    let xxx = props.location.state;


    return(
        <><center>

            <br></br>
            
            {xxx}

            <br></br>
            <br></br>


            <button 
                onClick={()=>{props.history.push('/board/Boardlist');}}
            >목록보기
            </button><br></br>
            
            <br></br>

        </center></>
    )
}
export default BoardContentForm;

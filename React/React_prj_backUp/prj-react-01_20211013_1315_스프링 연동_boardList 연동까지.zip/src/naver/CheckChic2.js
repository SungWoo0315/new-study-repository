// 클래스 컴포넌트로 작성한 것이다.
import React, { Component } from 'react';

class CheckChic2 extends Component {

    default_number = 0;

    state = {
        start_number : this.default_number 
                                            
        ,hen : this.default_number   
        ,cock : this.default_number   
    };

    // ============================
    add_hen = ( ) => { 
        this.setState( {hen : this.state.hen+1} )  
    };
    minus_hen = ( ) => { 
        this.setState( {hen : this.state.hen-1} )  
    };
    // ============================
    add_cock = ( ) => { 
        this.setState( {cock : this.state.cock+1} )  
    };
    minus_cock = ( ) => { 
        this.setState( {cock : this.state.cock-1} )  
    };
    // ============================
    init = ( ) => { 
        this.setState(
            { hen : this.state.start_number, cock : this.state.start_number  }
        );
    };
    // ============================

    
    render( ) {
        const { hen, cock } = this.state;
       

        if(hen<0 || cock<0){
            alert("음수로 내려갈수 없습니다.")
            this.setState(
                { hen : this.state.start_number, cock : this.state.start_number  }
            );
        }

        return(
            <>
                <center>
                CheckChic2
                    <table>
                        <tr>
                            <th colSpan="3">
                                총 : {hen+cock} 마리 <br/>
                                <br/>
                            </th>
                        </tr>
                        <tr>
                            <td align="center">
                                <button onClick={this.add_hen}> +1 </button> 
                                &nbsp;
                                <button onClick={this.minus_hen}> -1 </button> <br/>
                                암병아리 <br/> 
                                {hen} 마리 <br/>
                            </td>
                            <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            </td>
                            <td align="center">
                                <button onClick={this.add_cock}> +1 </button> 
                                &nbsp;
                                <button onClick={this.minus_cock}> -1 </button> <br/>
                                숫병아리 <br/> 
                                {cock} 마리 <br/>
                            </td>
                        </tr>
                    </table>
                        <br/>
                        <button onClick={this.init}> 초기값으로 </button> 
                </center>
            </>
    
        )

    }

}
export default CheckChic2;


   

import React, { Component } from 'react';

import './validation.css';


// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// [함수 컴포넌트] 선언하기
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class CheckLogin extends Component {

    passwordRef = React.createRef();
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 리액트가 지원하는 속성변수 state 선언하고 사용자 정의 객체({~})를 저장하기 
    // 속성변수 state 의 데이터 갱신은 setState(~)라는 메소드 호출로 갱신된다.  
    // setState(~) 메소드가 호출되어 state 변수 안의 데이터가 갱신되면 render 메소드가 재 호출되고 리턴되는
    // JSX 의 실행결과가 웹브라우저로 출력된다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    state = {
        password : ''
        ,id : ''
        ,clicked : false 
        ,validated : false
        ,validatedID : false
    };

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 속성변수 handleChange 선언하고 화살표 함수(=익명함수) 저장하기
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    handleChange = e => {
        // ------------------------------------------------
        // setState 메소드 호출하여 state 변수안의 데이터를 갱신한다.  
        // 즉, state 변수안의 사용정 객체 안의 속성변수 password 안의 값이 바뀌는 것이다.  
        // setState 메소드 호출 시 this. 을 붙여야 한다.  
        // setState 메소드 호출하면 render 메소드가 재 호출되고 리턴되는
        // JSX 의 실행결과가 웹브라우저로 출력된다.  
        // ------------------------------------------------
        this.setState(
            {password : e.target.value}
        );
            // ------------------------------------------------
            //  e.target.value => 이벤트가 발생한 것의 value 속성값을 의미한다. 
            //                    즉, 이벤트가 발생한 입력의 입력/선택값을 말한다.
            //  <주의> 매개변수 e 에는 이벤트를 관리하는 객체가 들어온다.  
            //          target 이벤트 관리 객체의 속성변수로 이벤트가 발생한 입력양식을 관리하는 객체가 저장되어 있다.
            //          value 는 입력양식을 관리하는 객체의 속성변수로 입력 또는 선택한 값이 저장되어 있다.    
            // ------------------------------------------------
    };


    handleChangeID = e => {
        this.setState(
            {id : e.target.value}
        );
    };


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 속성변수 handleButtonClick 선언하고 화살표 함수(=익명함수) 저장하기
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    handleButtonClick = () => {
        // ------------------------------------------------
        // setState 메소드 호출하여 state 변수를 갱신한다.
        // setState 메소드 호출 시 this. 을 붙여야 한다.  
        // setState 메소드 호출하면 render 메소드가 재 호출되고 리턴되는
        // JSX 의 실행결과가 웹브라우저로 출력된다.  
        // ------------------------------------------------
        this.setState(
            {
                clicked : true
                ,validated : this.state.password === '0000'
                ,validatedID : this.state.id === 'abc'
            }
        );
    };


    keyPress = e => {
        if ( e.key === 'Enter' ){
            this.handleButtonClick();
        }
    }

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // render 메소드 선언하기
    // render 메소드는 [클래스 컴포넌트]를 처음 호출할때, setState 메소드 호출할 때 재 호출된다.
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    render() {

        return(
            <>
            <center>
                <br/><br/><br/><br/>
                {/* **************************** */}
                {/* 암호 입력 양식 태그 선언하기 */}
                {/* **************************** */}
                <table>
                    <tr>
                        <th> 아이디 : &nbsp; </th>
                        <th>
                       <input 
                                type="text" 
                                value={this.state.id}
                                onChange={this.handleChangeID}
                                onKeyPress={this.keyPress}
                                className={
                                    // ----------------------------------------
                                    // 만약 속성변수 clicked 가 
                                    // true 면 
                                    // (this.state.validated?'success':'failure') 의 실행결과를 리턴해서 className 에 저장하기
                                    // false 면
                                    // '' 리턴해서 className 에 저장하기 
                                    // ----------------------------------------
                                    this.state.clicked
                                    ?
                                        (this.state.validatedID?'success':'failure')
                                    :
                                        ''
                                }
                        />&nbsp;
                        </th>
                    </tr>
                    <tr>
                        <th>암호 : </th>
                        <th>
                            <input 
                                type="password" 
                                maxLength="4"
                                value={this.state.password}
                                onChange={this.handleChange}
                                onKeyPress={this.keyPress}
                                className={
                                    // ----------------------------------------
                                    // 만약 속성변수 clicked 가 
                                    // true 면 
                                    // (this.state.validated?'success':'failure') 의 실행결과를 리턴해서 className 에 저장하기
                                    // false 면
                                    // '' 리턴해서 className 에 저장하기 
                                    // ----------------------------------------
                                    this.state.clicked
                                    ?
                                        (this.state.validated?'success':'failure')
                                    :
                                        ''
                                }
                            />&nbsp;
                        </th>
                    </tr>
                </table>
                        <button onClick={this.handleButtonClick}>검증하기</button>
            </center>
            </>
        )
    };
};
export default CheckLogin;


















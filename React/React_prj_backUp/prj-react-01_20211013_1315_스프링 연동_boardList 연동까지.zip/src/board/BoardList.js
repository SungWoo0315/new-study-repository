import React, {useState, useRef, useEffect} from 'react';
import axios from "axios";

function BoardList(props) {

    const [searchCdt, setSearchCdt] = useState( {keyword1:''} );
    const [searchResult, setSearchResult] = useState( {} );

    // 로그인 성공하면 다 실행하고, search() 함수 실행.  
    // 접속하자마자, 함수 실행하게하기.
    // 맨처음 들어왔을 때 DB 연동해서 리스트 나오게 해야함.  
    useEffect(
        ()=>{
            search();
        }
        ,[]
    );


    const search = (e) => {
        axios.post(
            'http://localhost:8081/naver/boardList.do'
            , searchCdt
        ).then(
            responseJson => {
                setSearchResult( {...searchResult, ...responseJson.data} )
                // alert(responseJson.data.boardListAllCnt)
            }
        ).catch(
            function (error) {
                alert(error.message);
            }
        )
    }


    return(
        <><center>
            <br></br>
            [키워드] : <input   
                            type="text"
                            name="keyword1"
                        />

            <br></br>
            <br></br>

            <button onClick={search}>검색</button>{' '}
            <button>모두검색</button>{' '}
            <button 
                onClick={()=>{props.history.push('/board/loginForm');}}
            >로그아웃
            </button><br></br>
            
            <br></br>

            {/* ****************************************** */}
            {searchResult.boardListAllCnt} 개
            {/* ****************************************** */}
            <table border="0" cellPadding="5" cellSpacing="0">
                <tr bgcolor="lightgray">
                    <th>번호</th>
                    <th>제목</th>
                    <th>조회수</th>
                    <th>등록일</th>
                </tr>
                {
                    searchResult.boardList==null
                    ?
                    null
                    :
                    searchResult.boardList.map(
                        (board,i)=>
                            <tr>
                                <td>
                                    {
                                        searchResult.boardListAllCnt
                                        -
                                        (searchResult.selectPageNo*20-20+1)+1-i
                                    }
                                </td>
                                <td>{board.subject}</td>
                                <td>{board.readcount}</td>
                                <td>{board.reg_date}</td>
                            </tr>
                    )

                }
            </table>
            {/* ****************************************** */}
            <br></br>

                {/* 페이지 처리 및 작업에 필요한 데이터 꺼내지는지 테스트 */}
                {searchResult.last_pageNo} <br/>
                {searchResult.min_pageNo} <br/>
                {searchResult.max_pageNo} <br/>
                {searchResult.selectPageNo} <br/>
                {searchResult.rowCntPerPage} <br/>
                {searchResult.pageNoCntPerPage} <br/>

        </center></>
    )
}
export default BoardList;

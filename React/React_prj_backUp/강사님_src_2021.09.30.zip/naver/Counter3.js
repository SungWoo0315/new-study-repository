//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명/node_modules/react 안에 default 가 붙어 수출하는 놈을 수입해서 
	// 현재 파일 안에서 React 란 이름으로 사용할꺼야!
// 프로젝트명/node_modules/react 안에 default 가 안 붙어 수출하는 놈 useState 을 수입해서 
	// 현재 파일 안에서 useState 란 이름으로 사용할꺼야!
//---------------------------------------------------------------
// <참고> 아래 수입 코드는 함수 컴포넌트가 선언되는 js 파일안에서는 필수로 수입되는 놈들이다.
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { useState } from 'react';



//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function Counter2() {
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 default_number  선언하고 0 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const default_number = 0;

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 number, setNumber 선언하고 
	// 리액트가 제공하는 내장 함수  useState(default_number) 를 호출하여
	// 지역변수 number 에 default_number 변수안의 데이터를 저장하고
	// 지역변수 setNumber 에  number 변수 안의 데이터를 수정하는 익명함수 저장하기..
	//--------------------------------------------
	// 이제 부터 setNumber 변수안의 익명함수를 호출하여 
	// number 변수 안의 데이터가 갱신 되면 Counter2 함수가 재호출된다.
	// 단 useState(~) 함수가 호출되는 코딩 줄은 제외된다.
	//--------------------------------------------
	// setNumber 변수안의 익명함수를 호출하는 방법은  setNumber(number변수안에저장될데이터) 이다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [number, setNumber] = useState(default_number);


	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 지역변수 add, minus, ini 선언하고 화살표 함수 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const add = ( ) => {  
		setNumber( number+1 ); 
	};
	const minus = ( ) => {  
		setNumber( number-1 ); 
	};
	const init = ( ) => {  
		setNumber( default_number ); 
	};

	const xxx = ( number ) => {  
		setNumber( number ); 
	};

	return (
		<>
			<center>
				<hr/>Counter3<hr/>
				시작값: {default_number}<br/>
				현재값: {number}<br/>
				<button onClick={()=>xxx(number+1)} > +1 </button> &nbsp;&nbsp;
				
				<button onClick={()=>xxx(number-1)} > -1 </button> &nbsp;&nbsp;
				
				<button onClick={()=>xxx(default_number)} > 초기값으로 </button> &nbsp;&nbsp;
			</center>
		</>
	)
}


export default Counter2;
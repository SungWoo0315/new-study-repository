import React, { useState } from 'react';
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function CheckChic() {
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [m_number, setM_number] = useState(0);
	const [w_number, setW_number] = useState(0);
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const m_add = ()=>{
		setM_number(m_number+1);
	} 
	const m_minus = ()=>{
		setM_number(m_number-1);
	} 
	const w_add = ()=>{
		setW_number(w_number+1);
	} 
	const w_minus = ()=>{
		setW_number(w_number-1);
	} 

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	return (
		<>
		<center>
			<hr/> 
			총 : {m_number+w_number}  마리
			<hr/>
			숫병아리 : <button  onClick={m_add} >+1</button> 
			<button  onClick={m_minus} >-1</button> {m_number} 마리
			<br/>
			암병아리 : <button  onClick={w_add} > +1 </button> 
			<button  onClick={w_minus} >-1</button> {w_number} 마리
		</center>
		</>
	)
}




/*
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
function CheckChic() {
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const [m_number, setM_number] = useState(0);
	const [w_number, setW_number] = useState(0);
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	const set = ( m_or_w, num )=>{
		if( m_or_w=="m"){
			setM_number(m_number+num);
		}
		else if( m_or_w=="w"){
			setW_number(w_number+num);
		}
	} 
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	return (
			<>
				<center>
					<hr/> 
					총 : {m_number+w_number}  마리
					<hr/>
					숫병아리 : <button  onClick={()=>set('m',1)} >+1</button> 
					<button  onClick={()=>set('m',-1)} >-1</button> {m_number} 마리
					<br/>
					암병아리 : <button  onClick={()=>set('w',1)} > +1 </button> 
					<button  onClick={()=>set('w',-1)} >-1</button> {w_number} 마리

				</center>
			</>
	)
}
*/
export default CheckChic;

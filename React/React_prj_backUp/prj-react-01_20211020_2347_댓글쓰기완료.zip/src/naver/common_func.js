
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
export function isEmpty(str){

    let result = false;
    let dataType = typeof(str);
    // alert(dataType)
    /*
    if( dataType!="string" ){
        alert("isEmpty 함수 호출 시 매개변수에는 문자가 들어와야 합니다.")
        result = result;        
    }
    */
    if ( 
        dataType=="string" 
        && (str=="" || str.split(" ").join("")=="" )
    ){
        result = true;        
        // alert("문자가 들어와서 true 를 리턴합니다.")
    }
    return result;
}
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
export function isNotEmpty(str){
    return !isEmpty(str);
}
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm


// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
export function is_from_arr(targetArr, keywordStr) {
    let result = false;

    // 반복문 돌리기전에 항상 null 이 있는지 아닌지 확인을 해야 한다.  
    if(targetArr!=null){
        for(let i=0; i<targetArr.length; i++){
            if( targetArr[i]==keywordStr ){
                result = true;
                break;
            }
        }
    }
    return result;
}
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm


// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
export function del_dupl(targetArr) {
    
    if(targetArr!=null){
        for(let i=0; i<targetArr.length-1; i++){
            for(let j=i+1; j<targetArr.length; j++){

                if( targetArr[i] == targetArr[j] ){
                    targetArr.splice(j, 1);
                    j--;
                }
            
            }
        }
    }
}
// mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm











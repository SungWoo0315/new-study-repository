
import React, { Component } from 'react';

	const Test = () => {
		return (
			<div>
				&nbsp;&nbsp;&nbsp;새로 만들었습니다!
				<br></br>
				<br></br>
				&nbsp;&nbsp;&nbsp;하하하하!!!!
				<br></br>
				<br></br>
				&nbsp;&nbsp;&nbsp;하하하하!!!!
			</div>
		)
	}

export default Test;
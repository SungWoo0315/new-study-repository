import logo from './logo.svg';
import './App.css';

import React, {Component} from 'react';
import { Route } from 'react-router-dom';
// import Test from './naver/Test';  // 테스트 끝나서 주석처리.


import Counter from './naver/Counter';
import Counter2 from './naver/Counter2';

function App() {
  return (
    <div>
      {/* <Route path="/naver/test" component={Test}></Route> */} 
      
      {/* --------------------------------------------  */}
      {/* URL 주소가 ~:3000/naver/Counter 일 경우 Counter 컴포넌트 호출해라  */}
      {/* --------------------------------------------  */}
      <Route path="/naver/Counter" component={Counter}></Route>

      {/* --------------------------------------------  */}
      {/* URL 주소가 ~:3000/naver/Counter2 일 경우 Counter2 컴포넌트 호출해라  */}
      {/* --------------------------------------------  */}
      <Route path="/naver/Counter2" component={Counter2}></Route>
    </div>







    // <>
    // <div className="App">
    //   <header className="App-header">

    //   {/* --------------------------------------------  */}
    //   {/* 주석처리 */}
    //   {/* --------------------------------------------  */}
    //   안녕하세요 React 입니다!....<br/>
    //   하하하하핳...
    //   hahaha<br/>
    //   겨우 들어왔다...
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // <div>

    // </div>  
    // </div>
    // </>
  );
}

export default App;

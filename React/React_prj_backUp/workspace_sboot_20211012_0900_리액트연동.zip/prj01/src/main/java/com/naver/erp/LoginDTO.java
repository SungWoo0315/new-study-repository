package com.naver.erp;

public class LoginDTO {

	//--------------------------------------------
	private String login_id;
	private String pwd;
	private int[] xxx;
	//--------------------------------------------
	public String getLogin_id() {
		return login_id;
	}
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public int[] getXxx() {
		return xxx;
	}
	public void setXxx(int[] xxx) {
		this.xxx = xxx;
	}
	
	
	
	
	
	
	

	
}

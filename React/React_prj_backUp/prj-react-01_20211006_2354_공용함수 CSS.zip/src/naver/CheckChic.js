// 함수 컴포넌트로 작성한 것이다.
import React, { useState } from 'react';

function CheckChic() {

    const default_number = 0;

    const [hen, setNumber] = useState(default_number);
    const [cock, setNumber2] = useState(default_number);


    // // 밑에 4가지 계산함수를 하나로합치기.
    // const calc = (chic, num) => {
    //     if( chic=="hen"){
    //         alert("일단 들어옵니다.")
    //         setNumber( hen+num );
    //     }
    //     else if( chic=="cock"){
    //         setNumber( cock+num );
    //     }
    // };

    // ============================
    const add_hen = ( ) => { 
        setNumber( hen+1 ); 
    };
    const minus_hen = ( ) => { 
        setNumber( hen-1 ); 
    };
    // ============================
    const add_cock = ( ) => { 
        setNumber2( cock+1 ); 
    };
    const minus_cock = ( ) => { 
        setNumber2( cock-1 ); 
    };
    // ============================
    const init = ( ) => { 
        setNumber( default_number ); 
        setNumber2( default_number ); 
    };
    // ============================

    if(hen<0 || cock<0){
        alert("음수로 내려갈수 없습니다.")
        setNumber( default_number ); 
        setNumber2( default_number ); 
    }

    return(
        <>
            <center>
            CheckChic
                <table>
                    <tr>
                        <th colSpan="3">
                            총 : {hen+cock} 마리 <br/>
                            <br/>
                        </th>
                    </tr>
                    <tr>
                        <td align="center">
                            <button onClick={add_hen}> +1 </button> 
                            &nbsp;
                            <button onClick={minus_hen}> -1 </button> <br/>
                            암병아리 <br/> 
                            {hen} 마리 <br/>
                        </td>
                        <td>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        </td>
                        <td align="center">
                            <button onClick={add_cock}> +1 </button> 
                            &nbsp;
                            <button onClick={minus_cock}> -1 </button> <br/>
                            숫병아리 <br/> 
                            {cock} 마리 <br/>
                        </td>
                    </tr>
                </table>
                    <br/>
                    <button onClick={init}> 초기값으로 </button> 
            </center>
        </>

    )
}
export default CheckChic;

import React, {useState, useRef, useEffect} from 'react';
import axios from "axios";

function BoardRegForm(props) {
    
    const b_no = props.location.state.b_no;

    const [board, setBoard] = useState( {b_no:b_no} );   

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const change = (e) =>{
        setBoard( {...board, [e.target.name]:e.target.value} );
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 지역변수 regBoard 선언하고   
    // 새글쓰기 또는 댓글쓰기 버튼 클릭 시 실행할 구문을 내포한 화살표함수 저장하기   
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const regBoard = () =>{
        // alert( board.subject + " / " + board.writer + " / " + board.content )
        // alert("test")
        axios.post(
            'http://localhost:8081/naver/boardRegProc.do'   // URL 주소  
            ,board                                      // 전송할 데이터
        ).then(
            responseJson => {

                let regCnt = responseJson.data.boardRegCnt;
                let msg = responseJson.data.msg;

                if( msg!="" ){
                    alert(msg);
                    return;
                }
                if( regCnt==1 ){
                    alert( (b_no<1?'새글쓰기':'댓글쓰기') + "성공!")
                    props.history.push('/board/Boardlist');
                }
            }
        ).catch(
            // 서버의 응답이 실패했을 때 실행할 코딩을 내포한 화살표 함수 선언하기
            (error) => {
                alert("서버 연동 실패! : " + error.message);
            }
        )
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    
    return(
        <><center>

            test : 

            {props.location.state.b_no} 

            <br/>
            <br/>

            {/* --------------------------------------------------- */}
            <table cellPadding='5' cellSpacing='0' bordercolor='lightgray' border='1' style={{borderCollapse:'collapse'}}>
                <caption>{b_no===0?'새글쓰기':'댓글쓰기'}</caption>
                <tr>
                    <th bgcolor='#efefef'>제목</th>
                    <td><input type='text' name='subject' value={board.subject} onChange={change} /></td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>작성자</th>
                    <td><input type='text' name='writer' value={board.writer} onChange={change} maxLength='30'></input></td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>이메일</th>
                    <td><input type='text' name='email' value={board.email} onChange={change} maxLength='30'></input></td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>내용</th>
                    <td>    
                        <textarea 
                                name='content'
                                rows='20' cols='50'
                                value={board.content}
                                onChange={change}
                        >
                        </textarea>
                    </td>
                </tr>
                <tr>
                    <th bgcolor='#efefef'>암호</th>
                    <td><input type='password' name='pwd' value={board.pwd} onChange={change}></input></td>
                </tr>
            </table>
            {/* --------------------------------------------------- */}


            {/* 공백조절 */}
            <div style={{height:'10pt'}}></div>   

            <button onClick={regBoard}>{b_no===0?'새글쓰기':'댓글쓰기'}</button>{' '}
            <button onClick={()=>{props.history.push('/board/Boardlist');}}>목록보기</button>{' '}
            <button onClick={()=>{props.history.push('/board/LoginForm');}}>로그아웃</button><br></br>
            
        </center></>
    )
}
export default BoardRegForm;

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 클래스 컴포넌트로 작성한 것이다.
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { Component } from 'react';

class CheckChic4 extends Component {
    // MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    default_number = 0;

    state = {
        start_number : this.default_number 
                                            
        ,hen : this.default_number   
        ,cock : this.default_number   
    };
    // MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM

    calcChic = (chic, num) => {

        const { hen, cock } = this.state;

        // 만약 num 이 음수이고 숫/암병아리 수가 0이면 경고하고 함수 중단하기 
        if(num<0){
            if(chic=="hen" && hen==0){
                alert('암병아리가 0개 미만일수 없습니다.')
                return;
            }
            else if(chic=="cock" && cock==0){
                alert('숫병아리가 0개 미만일수 없습니다.')
                return;
            }
        }

        if( chic=="hen"){
            this.setState( {hen:hen+num} );
            
        }
        else if( chic=="cock"){
            this.setState( {cock:cock+num} );
        }
    };


    // ============================
    // 초기화에 필요한 코드
    init = ( ) => { 
        this.setState(
            { hen : this.state.start_number, cock : this.state.start_number  }
        );
    };
    // ============================

    
    render( ) {
        // const { hen, cock } = this.state;
        // 아래코드 두줄은 위 한줄 코드와 똑같다. 
        const hen = this.state.hen;
        const cock = this.state.cock;

       
        // 내가만든 음수 밑으로 못내려가게 하는 코드
        // if(hen<0 || cock<0){
        //     alert("음수로 내려갈수 없습니다.")
        //     this.setState(
        //         { hen : this.state.start_number, cock : this.state.start_number  }
        //     );
        // }

        return(
            <>
                <center>
                CheckChic4
                    <table>
                        <tr>
                            <th colSpan="3">
                                총 : {hen+cock} 마리 <br/>
                                <br/>
                            </th>
                        </tr>
                        <tr>
                            <td align="center">
                                <button onClick={()=>{this.calcChic('hen',+1)}}> +1 </button> 
                                &nbsp;
                                <button onClick={()=>{this.calcChic('hen',-1)}}> -1 </button> <br/>
                                암병아리 <br/> 
                                {hen} 마리 <br/>
                            </td>
                            <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            </td>
                            <td align="center">
                                <button onClick={()=>{this.calcChic('cock',+1)}}> +1 </button> 
                                &nbsp;
                                <button onClick={()=>{this.calcChic('cock',-1)}}> -1 </button> <br/>
                                숫병아리 <br/> 
                                {cock} 마리 <br/>
                            </td>
                        </tr>
                    </table>
                        <br/>
                        <button onClick={this.init}> 초기값으로 </button> 
                </center>
            </>
    
        )

    }

}
export default CheckChic4;


   

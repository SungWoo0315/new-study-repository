// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명 /node_modules/react 안에 default 가 붙어 수출하는 놈을 수입해서 현재 파일에서 변수 React 에 저장하기
// 프로젝트명 /node_modules/react 안에 default 가 안 붙어 수출하는 useState 함수를 수입해서 현재 파일에서 변수 useState 에 저장하기
// ---------------------------------------------------------------
// <참고> 클래스 컴포넌트를 선언할 경우 Component 함수를 사용한다.
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { Component } from 'react';

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [클래스 컴포넌트] 선언하기
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class Search_T2 extends Component {

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 속성변수 keywordRef 선언하고,
    // React 객체의 createRef() 메소드를 호출하여 리턴된 데이터를 저장하기.  
    // 이후부터 ref={keywordRef} 가진 태그는
    // this.keywordRef.current.focus(); 코딩이 실행되면
    // 포커스가 그 태그 안으로 들어간다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    keywordRef = React.createRef();

    developerList = [
        { dev_no : 1, dev_name : '사오정', addr : '서울시', phone : '010-1111-2222'}
        ,{ dev_no : 2, dev_name : '저팔계', addr : '제주시', phone : '010-2222-1212'}
        ,{ dev_no : 3, dev_name : '손오공', addr : '대구시', phone : '010-3333-2323'}
        ,{ dev_no : 4, dev_name : '삼장법사', addr : '부산시', phone : '010-4444-3434'}
        ,{ dev_no : 5, dev_name : '우마왕', addr : '김해시', phone : '010-5555-4545'}
        ,{ dev_no : 6, dev_name : '홍길동', addr : '전주시', phone : '010-6666-5656'}
        ,{ dev_no : 7, dev_name : '고길동', addr : '경주시', phone : '010-7777-6767'}
        ,{ dev_no : 8, dev_name : '정다운', addr : '서울시', phone : '010-8888-9922'}
        ,{ dev_no : 9, dev_name : '한국남', addr : '대구시', phone : '010-8872-1027'}
        ,{ dev_no : 10, dev_name : '둘리', addr : '서울시', phone : '010-4330-7819'}
        ,{ dev_no : 11, dev_name : '코난', addr : '제주시', phone : '010-6764-8021'}
        ,{ dev_no : 12, dev_name : '도우너', addr : '세종시', phone : '010-1263-5772'}
    ];

    state = {
        developers : this.developerList                  
        , inputText : ''          
    };

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 화살표 함수가 저장된 지역변수 textChange 선언.  
    // 아래 매개변수 e 에는 Event 객체가 들어온다. 
    // 즉, 아래 화살표함수는 입력 양식에 이벤트가 발생했을 때 실행할 구문을 내포하고 있다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    textChange = (e) => {
        this.setState({inputText : e.target.value});
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 화살표 함수가 저장된 지역변수 search 선언.  
    // 검색 버튼 누르면 실행할 구문을 내포하고 있다.
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    search = () => {

        // const developers = this.state.developers;
        const inputText = this.state.inputText;

        // --------------------------------------
        // 지역변수 tmp_inputText 선언하고
        // inputText 안의 문자 복사한 후 앞뒤 공백 제거하고
        // tmp_inputText 에 저장하기  
        // --------------------------------------
        const tmp_inputText = inputText.trim();
        // --------------------------------------
        // 지역변수 inputText 안에 문자 복사한 후 공백 제거하고 
        // 즉, 키워드 입력란을 비우기   
        // --------------------------------------
        this.setState({inputText: tmp_inputText});  

        // --------------------------------------
        // 지역변수 new_developerList 선언하고
        // Array 객체의 filter 메소드를 호출하여
        // developerList 에 저장된 사용정객체를 1개씩 복사해서 꺼내서
        // 화살표 함수를 호출하면서 매개변수로 전달시킨다.  
        // 화살표 함수의 리턴값이 true 면 매개변수로 들어온 사용정 객체를 누적시킨다.  
        // 즉, 입력한 키워드가 부분적으로 들어 있는 사용정 객체만 누적 시킨다.   
        // 즉, new_developerList 안에는 키워드가 들어 있는 사용정 객체만 모여있는 Array 객체가 저장되어 있다.
        // --------------------------------------
        const new_developerList = this.developerList.filter(
            developer => 
                developer.dev_name.indexOf(tmp_inputText)>=0
                ||developer.addr.indexOf(tmp_inputText)>=0
                ||developer.phone.indexOf(tmp_inputText)>=0
        );
        // --------------------------------------
        // new_developerList 안에 Array 객체 developers 지역변수 안에 넣기.  
        // 즉, 키워드가 들어 있는 사용정 객체들이 새롭게 developers 지역변수 안에 들어간 것이다.  
        // --------------------------------------
        this.setState({developers: new_developerList});

        // --------------------------------------
        // ref={keywordRef} 를 가진 태그에 커서 들여놓기 
        // --------------------------------------
        this.keywordRef.current.focus();
    };
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 화살표 함수가 저장된 지역변수 searchAll 선언.  
    // 모두 검색 버튼 누르면 실행할 구문을 내포하고 있다.
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    searchAll = () => {
        // --------------------------------------
        // 지역변수 inputText 안에 "" 저장하기.    
        // 즉, 키워드 입력란을 비우기   
        // --------------------------------------
        this.setState({inputText : ''});  
        // --------------------------------------
        // developerList 안에 Array 객체 developers 지역변수 안에 넣기.  
        // 즉, 원래 모든 데이터가 복구되는 셈이다.    
        // --------------------------------------
        this.setState({developers : this.developerList});
        // --------------------------------------
        // ref={keywordRef} 를 가진 태그에 커서 들여놓기 
        // --------------------------------------
        this.keywordRef.current.focus();
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 키워드 입력양식 엔터키로 작동하게 하기. 
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    keyPress = e => {
        if ( e.key === 'Enter' ){
            this.search();
        }
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    //  render 메소드 선언. 필수 1개 선언.
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    render( ) {

        // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
        // 지역변수 searchResultTag 선언.  
        // developers 안의 저장된 사용정 객체들 안의 데이터를 html 태그 형태로 누적시키기   
        // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
        const searchResultTag = this.state.developers.map(

            developer => 
                    <tr key={developer.dev_no}>
                        <td align="center">{developer.dev_no}</td>
                        <td align="center">{developer.dev_name}</td>
                        <td align="center">{developer.addr}</td>
                        <td align="center">{developer.phone}</td>
                    </tr>
        );
        // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

        // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
        // JSX 문법을 가진 return 구문 선언  
        // 리턴되는 JSX 문법이 웹화면에 출력된다.     
        // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
        return(
            <>
                <center>
                {/* {inputText} */}
                    <br/>
                    [키워드] : <input 
                        type='text' 
                        ref={this.keywordRef}
                        value={this.state.inputText}  
                        onKeyPress={this.keyPress}   
                        onChange={this.textChange}  
                    />
                    &nbsp;&nbsp;
                    <button onClick={this.search}>검색</button> &nbsp;
                    <button onClick={this.searchAll}>모두검색</button> &nbsp;&nbsp;

                    <br/><br/>

                    <table border="1" cellPadding="5" cellspacing="0">
                        <caption>검색 인원 : {this.state.developers.length} 명</caption>
                        <tr>
                            <th bgcolor="gray" width="50px">번호</th>
                            <th bgcolor="gray" width="100px">직원명</th>
                            <th bgcolor="gray" width="80px">거주지</th>
                            <th bgcolor="gray" width="150px">전화번호</th>
                        </tr>
                        {searchResultTag}
                    </table>
                    {this.state.developers.length==0?'검색결과 없음!!':null}
                </center>
            </>
        )
    }
};
export default Search_T2;



    
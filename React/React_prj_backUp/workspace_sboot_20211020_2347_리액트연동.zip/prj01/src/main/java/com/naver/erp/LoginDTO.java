package com.naver.erp;

public class LoginDTO {

	//--------------------------------------------
	private String login_id;
	private String pwd;
	private String is_login;
	//--------------------------------------------
	public String getLogin_id() {
		return login_id;
	}
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getIs_login() {
		return is_login;
	}
	public void setIs_login(String is_login) {
		this.is_login = is_login;
	}


	
	
	
	
	
	
	

	
}

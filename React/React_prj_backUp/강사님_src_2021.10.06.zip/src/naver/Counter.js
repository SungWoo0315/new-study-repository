//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명/node_modules/react 안에 default 가 붙어 수출하는 놈을 수입해서 
	// 현재 파일 안에서 React 란 이름으로 사용할꺼야!
// 프로젝트명/node_modules/react 안에 default 가 안 붙어 수출하는 놈 Component 을 수입해서 
	// 현재 파일 안에서 Component 란 이름으로 사용할꺼야!
//---------------------------------------------------------------
// <참고> 아래 수입 코드는 클래스 컴포넌트가 선언되는 js 파일안에서는 필수로 수입되는 놈들이다.
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { Component } from 'react';


//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [클래스 컴포넌트] 선언하기
// <참고> [클래스 컴포턴트]는 자바의 클래스와 유사한 행태를 기지고 있다.
// <주의> [클래스 컴포턴트]는 반드시 Component 클래스를 상속해야한다.
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
class Counter extends Component {
		
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 사용정(=개발자가 만든) 속성변수 선언하기. 
		// <참고>속성변수는 클래스 내부의 동료 속성변수나 메소드가 공유할 데이터를 저장하기 위함이다.
		// <주의>사용정 속성변수 선언 시  this.  을 붙이지 않는다.
		// <주의>호출 시  this.  을 붙인다.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	default_number = 1;



	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 리액트가 제공하는 state 속성변수 선언하고 [사용정 객체]를 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
		//-----------------------------------------------
		// 클래스 컴포넌트 안에서 리액트가 제공하는 state 속성변수 특징
		//-----------------------------------------------
			// state 속성변수의 갱신은 리액트가 제공하는 setState 메소드 호출로만 가능하다.
			// setState 메소드 호출로 state 속성변수 안의 값이 갱신 되면 rende 메소드가 재 호출된다.
			// state 속성변수 호출할 경우 this. 을 붙인다.
	state = {
		start_number:this.default_number  // 사용자 정의 객체안에 속성변수  start_number 선언하고 
		                                    // 바깥쪽 속성변수 default_number 안의 값을 저장하기
		,now_number:this.default_number    // 사용자 정의 객체안에 속성변수  now_number 선언하고 
		                                    // 바깥쪽 속성변수 default_number 안의 값을 저장하기
	};

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 사용정 속성변수 add 에 화살표 함수 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	add = ( )=>{ 
		//--------------------------------------------------
		// setState 라는 메소드 호출하여
		// state 변수 안의 저장된 사용정 객체 안의 속성변수 now_number 안의 데이터를
		// this.state.now_number+1 의 실행결과로 갱신하라
		//--------------------------------------------------
		// <주의>state 변수 안의 저장된 사용정 객체가 
		//       {now_number: this.state.now_number+1} 로 완전 갱신 된게 절대 아니다.
		//       즉 부분 갱신만 진행된 것이다.
		//--------------------------------------------------
		this.setState( 
			{now_number: this.state.now_number+1 }
		); 
	}


	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 사용정 속성변수 minus 에 화살표 함수 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	minus = ( ) => {  
		//--------------------------------------------------
		// setState 라는 메소드 호출하여
		// state 변수 안의 저장된 사용정 객체 안의 속성변수 now_number 안의 데이터를
		// this.state.now_number-1 의 실행결과로 갱신하라
		//--------------------------------------------------
		// <주의>state 변수 안의 저장된 사용정 객체가 
		//       {now_number: this.state.now_number-1} 로 완전 갱신 된게 절대 아니다.
		//       즉 부분 갱신만 진행된 것이다.
		//--------------------------------------------------
		this.setState( 
			{now_number: this.state.now_number-1 }
		); 
	};
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 사용정 속성변수 init 에 화살표 함수 저장하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	init = ( ) => {  
		//--------------------------------------------------
		// setState 라는 메소드 호출하여
		// state 변수 안의 저장된 사용정 객체 안의 속성변수 now_number 안의 데이터를
		// this.state.start_number 의 실행결과로 갱신하라
		//--------------------------------------------------
		// <주의>state 변수 안의 저장된 사용정 객체가 
		//       {now_number: this.state.start_number} 로 완전 갱신 된게 절대 아니다.
		//       즉 부분 갱신만 진행된 것이다.
		//--------------------------------------------------
		this.setState( 
			{now_number: this.state.start_number }
		); 
	};
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// render 메소드 필수 1개 선언. 
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	render( ) {
		//--------------------------------------------------
		// render 메소드 안에서만 사용가능한 
		// 지역변수 start_number, now_number 선언하고
		// 지역변수 start_number 에는 state 변수안의 사용정 객체 안의 start_number 속성변수의 값을 저장하기
		// 지역변수 now_number 에는 state 변수안의 사용정 객체 안의 now_number 속성변수의 값을 저장하기
		//--------------------------------------------------
		// 즉 지역변수명과 일치하는 사용정객체의 속성변수 안의 값을 지역변수에 저장하기
		//--------------------------------------------------
		// <참고> 아래 코딩을 달리해 표현한다면 이와 같다.
			// const start_number = this.state.start_number;
			// const now_number = this.state.now_number;
		//--------------------------------------------------
		const { start_number, now_number } = this.state; 
		//-------------------------
		// return 구문 필수 선언. 
		//-------------------------
		return (
			<>
				<center>
				{/*-----------------------------------------------*/}
				{/* render 메소드 안에 선언된 start_number 라는 지역변수 안의 값을 표현하기 */}
				{/*-----------------------------------------------*/}
				시작값 : {start_number} <br/>

				{/*-----------------------------------------------*/}
				{/* render 메소드 안에 선언된 now_number 라는 지역변수 안의 값을 표현하기 */}
				{/*-----------------------------------------------*/}
				현재값 : {now_number} <br/>

				{/*-----------------------------------------------*/}
				{/* +1 이 들어간 버튼을 클릭하면 속성변수 add 안의 화살표 함수 안의 코딩을 실행하기 */}
				{/*-----------------------------------------------*/}
				<button onClick={this.add}> +1 </button> &nbsp;&nbsp;

				{/*-----------------------------------------------*/}
				{/* -1 이 들어간 버튼을 클릭하면 속성변수 minus 안의 화살표 함수 안의 코딩을 실행하기 */}
				{/*-----------------------------------------------*/}
				<button onClick={this.minus} > -1 </button> &nbsp;&nbsp;

				{/*-----------------------------------------------*/}
				{/*  초기값으로 이 들어간 버튼을 클릭하면 속성변수 init 안의 화살표 함수 안의 코딩을 실행하기 */}
				{/*-----------------------------------------------*/}
				<button onClick={this.init} > 초기값으로 </button>

				</center>
			</>
		)
	}

}



//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 현재 이 파일 안에서 기본적으로 수출할 컴포넌트 지정하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
export default Counter;


/*
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문>위에 있는 Counter 클래스 컴포넌트는 지금 어디서 누가 호출했나?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	 URL 주소가 ~:3000/naver/counter    일 경우
	 App.js 에서 아래 코딩에 의해 호출되었다.
	-------------------------------------------------------
	 <Route path="/naver/counter" component={Counter}/>
	-------------------------------------------------------

nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문>위에 있는 Counter 클래스 컴포넌트가 호출되면(=실행되면) 어떤 일이 벌어지나?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	(1) 생성자가 있으면 생성자를 호출한다.
	(2) 속성변수하고 메소드를 읽어 들인다.
	(3) render 메소드를 호출한다.
	(4) render 메소드가 린턴하는 JSX 문법을 [화면 출력 기능의 자바스크립트]로 바꾸고 클라이언트 브라우저로전송한다.
	(5) 클라이언트 브라우저가 [화면 출력 기능의 자바스크립트]을 읽어 들여 화면에 출력한다.
	--------------------------------------------------------------------------
	(6) 만약 이벤트가 발생하여 자스 코딩이 실행되는 과정에서 [setState 메소드]가 호출되어
	    state 속성변수 안의 값이 변경되면 [render 메소드]를 재 호출한다.
		재 호출되어 출력되는 컨텐츠가 이전 화면 컨텐츠를 모두 갱신하는게 아니라
		달라진 부분만 갱신시켜 버린다.
		리로드가 아니다.
	--------------------------------------------------------------------------
	    즉 화면에 부분 변화를 일으키고 싶으면 이벤트에 의해 실행되는 
		자스 코딩안에 [setState 메소드]가 호출되게 만들어 버리면된다.
		리액트가 아닌 HTLML 이나 JSP에서의 자스에서도 이런 효과를 볼수는 있지만
		그러나 리액트보다는 일부 화면 변화 시 부하가 훨씬 더 걸린다.
	
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> 허걱 const { start_number, now_number } = this.state;  코딩은 무슨 의미인가요?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
		//--------------------------------------------------
		// 지역변수명과 일치하는 사용정객체의 속성변수 안의 값을 지역변수에 저장하기
		//--------------------------------------------------
		//  달리해 표현한다면 아래와 같다.
			// const start_number = this.state.start_number;
			// const now_number = this.state.now_number;
		//--------------------------------------------------
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> <br/> 를 <br>  로 고치면?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	완벽한 에러가 발생한다. 화면에 출력되지 않을 정도의 에러가 발생한다.
	JSX 문법의 1순위
		모든 태그는 여는 태그가 있으면 후에 닫는 태그가 반드시 꼭 나와야한다.
		여는 태그만 있는 태그는 여는 태그 마지막에 / 나와야한다.
	현재 <br> 는 여는 태그만 있는 태그이므로 <br/> 로 해야 에러가 없다.

nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> <> 와 </> 를 생략하면?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	에러 없다.
	<> 와 </> 를 생략하면 center 태그 하나가 최상위 태그가 되므로 에러가 없다.

	
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> const, var, let 이게 뮘까?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	변수 선언 시 변수 외쪽에  붙이는 키워드이다.
	사용범위, 갱신 여부, 중복 선언 여부에 관한 설정이다.

	***********************************************************************************************
	종류	       사용 가능 영역    초기화 이후 갱신 가능 여부     동일한 변수 중복 선언 가능여부
	***********************************************************************************************
	var             함수 내부              가능                               0
	-------------------------------------------------------------------------------------------------
	let             블록({~}) 내부         가능                               X
	-------------------------------------------------------------------------------------------------
	const           블록({~}) 내부         불가능                             X
	-------------------------------------------------------------------------------------------------

nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> 태그에 이벤트가 발생하면 자스 코딩을 실행하고 싶다.
     react 에서는 어떠케 설정해야하나?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
		--------------------------------------------------------
		<태그명  on이벤트명={실행구문을내포한화살표함수저장변수명} >
		--------------------------------------------------------
		<태그명  on이벤트명={실행구문을내포한화살표함수} >
		--------------------------------------------------------
			--------------------------------------------------------
			<주의> 아래처럼 안되지!
			--------------------------------------------------------
				<태그명  on이벤트명={실행구문} >                       => X
				<태그명  on이벤트명="실행구문을내포한화살표함수" >     => X
			--------------------------------------------------------
			<주의> 이벤트명은 대문자로 시작해야함. 즉 카멜 표기법 준수 해야함.
			--------------------------------------------------------
				<태그명  onclick={~} >   => X.  onclick 을 onClick
				<태그명  onKeyup={~} >   => X.  onKeyup 을 onKeyUp
			

			
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> this.setState(    {now_number: this.state.now_number+1 }  ); 
     이 코딩이 무얼 의미하나?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	----------------------------------------------------
	state 속성변수  안의 값을 일부 수정하는 코딩이다.
	----------------------------------------------------
	//--------------------------------------------------
	// state 변수 안의 저장된 사용정 객체 안의 속성변수 now_number 안의 데이터를
	// this.state.now_number+1 의 실행결과로 부분 갱신하라
	//--------------------------------------------------
	// <주의>state 변수 안의 저장된 사용정 객체가 
	//       {now_number: this.state.now_number+1} 로 완전 갱신 된게 절대 아니다.
	//       즉 부분 갱신만 진행된 것이다.
	//--------------------------------------------------

nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> this.setState(    {now_number: this.state.now_number+1 }  ); 
     이 코딩이 실행되는 무슨 일이 벌어지는가?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
		render 메소드 안의 코딩이 재 실행이 된다.
		실행결과 화면과 이전 화면을 비교해서 바뀐부분만 적용되어 일부 수정이 된다.
		JQuery 도 이런 기능이 있지만 리액트를 사용했을 때 보다 부하가 많이 걸린다.



nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> add = ( )=>{ ~ };  코딩을 add = function( ){ ~ }; 로 수정하면?
     즉 화살표 함수를 보통의 익명함수로 수정하면?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
		-----------------------------------------------------
		처음 화면 열때는 에러가 발생하지 않는다.
		+1  버튼을 눌러서 add 안의 익명함수 안의 코딩이 실행될때 에러 발생한다.
		-----------------------------------------------------
		익명 함수안에서 this.속성변수 또는 this.메소드명(~) 이 나오면
		this.속성변수 또는 this.메소드명(~) 를 안고 있는 객체 내부의 속성변수 나 메소드를 지칭한다.
		에러가 난 이유는 
		{now_number: this.state.now_number-1 }  안의 this.state 는 최종 바깥에 있는 state 속성변수를 지칭하는게 아니라
		{now_number: this.state.now_number-1 } 안의 state 속성변수를 지칭하게된다.
		없으므로 에러가 발생한다.
		-----------------------------------------------------
		화살표 함수안에서 this.속성변수 또는 this.메소드명(~) 이 나오면
		최종 바깥에 있는 클래스의 속성변수 나 메소드를 지칭한다.

nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> return 안에서 나오는    시작값 : {start_number}       게      뭠까?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	return 안에서는 JSX 문법이 등장한다.
	JSX 문법의 실행 결과가 웹브라우저 출력된다고 생각하면 된다.
	JSX 문법은  주로 HTML 태그, 사용자정의 태그, {자스데이터} 또는 {자스변수} 로 구성되어 있다.
	이 중에서 {자스데이터} 는 자스데이터를 표현해 출력하라는 뜻이다.
	결국 {start_number} 는 지역변수 start_number 안의 데이터를 표현하라는 말이다.
	-----------------------------------------------------
	= 왼쪽이 아닌 곳에 나오는 모든 변수는 데이터라고 봐야한다.
	즉 변수 안의 데이터를 봐야한다.
	
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
<문> 일회성 사용자 정의 객체가 뭠까?
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	-------------------------------------------------
	아래와 같은 형식으로 선언되는 객체를 말한다.
	-------------------------------------------------
	변수 = {
		속성변수명:데이터
		,속성변수명:데이터
		,~
		,속성변수명:데이터
	}
	-------------------------------------------------
	<주의> 속성변수명은 중복될 경우 마지막이 진짜 속성변수라고 본다.
	-------------------------------------------------
	-------------------------------------------------
	<예>
	-------------------------------------------------
		employee = {
			emp_no:1
			,emp_name:"사오정"
			,jikup:"과장"
		}
	-------------------------------------------------
	<참고> 자스의 데이터 종류는?
	-------------------------------------------------
		숫자
		문자
		boolean (true  또는 false)
		익명함수 또는 화살표함수
		객체
		undefined
		-------------------------------------------------
		<주의> undefined 와 null ?
		-------------------------------------------------
			null 은 참조형 즉 객체형이다.
			undefined 는 5가지 아닌 경우에 데이터는 모두 undefined 취급한다.
			----------------------------
			<예> undefined 의 예
			----------------------------
				function xxx(a,b){~};
				xxx(1);
				일 경우 xxx 함수의 매개변수 a 에는 1 이 저장되고 b 에는 undefined 가 저장되어 있다.
			----------------------------
			<예> undefined 의 예
			----------------------------
				var xxx;    => undefined 가 저장되어 있다.
			----------------------------
			<예> null 의 예
			----------------------------
				var xxx = null;   // 추후에 객체생성 후 객체의 메위주를 저장할 꺼야. 
				                  // 그러니까 다른 데이터는 저장마! 라는 경고.
*/
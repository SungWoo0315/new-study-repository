// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명 /node_modules/react 안에 default 가 붙어 수출하는 놈을 수입해서 현재 파일에서 변수 React 에 저장하기
// 프로젝트명 /node_modules/react 안에 default 가 안 붙어 수출하는 useState 함수를 수입해서 현재 파일에서 변수 useState 에 저장하기
// ---------------------------------------------------------------
// <참고> 함수 컴포넌트를 선언할 경우 대부분 useState 함수를 사용한다.
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { useState, useRef } from 'react';

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
const RegData = () => {

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 지역변수 nameRef 선언하고,
    // useRef 함수를 호출하여 리턴된 데이터를 저장하기.  
    // 이후부터 ref={nameRef} 가진 태그는
    // nameRef.current.focus(); 코딩이 실행되면
    // 포커스가 그 태그 안으로 들어간다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const nameRef = useRef(null);

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 지역변수 names, setNames 선언하고
    // 지역변수 names 에는 {~} 즉, Array 객체 저장하고 
    // 지역변수 setNames 에는 지역변수 names 안을 갱신하는 익명함수 저장하기
    // 이후 부터 setNames(~) 이 호출되면 함수컴포넌트 안의 코딩이 재 실행된다.
    // 재 실행 시 useState 함수 호출이 있는 코딩줄은 재 실행에서 제외된다.  
    // 이제부터 names 는 마치 클래스 컴포넌트의 state 속성변수와 동일한 성격을 가지게 된다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [names, setNames] = useState(
        [
            { id : 1, text : '사오정'}
            ,{ id : 2, text : '저팔계'}
            ,{ id : 3, text : '손오공'}
            ,{ id : 4, text : '삼장법사'}
            ,{ id : 5, text : '우마왕'}
        ]
    );
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 지역변수 inputText, setInputText 선언하고
    // 지역변수 inputText 에는 {~} 즉, Array 객체 저장하고 
    // 지역변수 setInputText 에는 지역변수 inputText 안을 갱신하는 익명함수 저장하기
    // 이후 부터 setInputText(~) 이 호출되면 함수컴포넌트 안의 코딩이 재 실행된다.
    // 재 실행 시 useState 함수 호출이 있는 코딩줄은 재 실행에서 제외된다.  
    // 이제부터 inputText 는 마치 클래스 컴포넌트의 state 속성변수와 동일한 성격을 가지게 된다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [inputText, setInputText] = useState('');

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 지역변수 nextId, setNextId 선언하고
    // 지역변수 nextId 에는 {~} 즉, Array 객체 저장하고 
    // 지역변수 setNextId 에는 지역변수 nextId 안을 갱신하는 익명함수 저장하기
    // 이후 부터 setNextId(~) 이 호출되면 함수컴포넌트 안의 코딩이 재 실행된다.
    // 재 실행 시 useState 함수 호출이 있는 코딩줄은 재 실행에서 제외된다.  
    // 이제부터 nextId 는 마치 클래스 컴포넌트의 state 속성변수와 동일한 성격을 가지게 된다. 
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [nextId, setNextId] = useState(names.length+1);

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 화살표 함수가 저장된 지역변수 textChange 선언.  
    // 아래 매개변수 e 에는 Event 객체가 들어온다. 
    // 즉, 아래 화살표함수는 입력 양식에 이벤트가 발생했을 때 실행할 구문을 내포하고 있다.  
    // 이벤트 객체를 생성하지 않아도 알아서 생성되어 들어간다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const textChange = (e) => {
        
        // 지역변수 val 선언하고 이벤트가 발생한 놈의 value 값을 저장하기  
        let val = e.target.value;

        // 앞뒤 공백 제거하고 재 저장하기
        val = val.trim();
        // --------------------------------------
        // trim 쓰지않고 앞뒤 공백 제거하는 코드
        // --------------------------------------
        // while( val.indexOf(" ")==0 ){
        //     val = val.substring(1)
        // }
        // while( val.lastIndexOf(" ")==val.length-1 ){
        //     val = val.substring(0, val.length-1)
        // }


        // 지역변수 val 안의 지역변수 inputText 에 저장하기.  
        // <참고> value 속성을 가진 놈은 입력양식 태그 밖에 없다.  
        setInputText(val);
    }

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 화살표 함수가 저장된 지역변수 add 선언.
    // 화살표 함수 안에는 추가 버튼 클릭 시 호출되는 실행구문을 내포하고 있다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const add = () => {
        // ---------------------------------------------------
        // 만약 입력한 데이터가 비어있으면 경고하고 함수 중단.
        // ---------------------------------------------------
        if(inputText==null || inputText==undefined || inputText=='' || inputText.split(" ").join("")==''){
            alert("길이없는 데이터는 안됩니다. \n안돼! 돌아가!")
            setInputText("");

            // -----------------------------------------
            // ref={nameRef} 가진 태그에 포커스 들여놓기
            // -----------------------------------------
            nameRef.current.focus();
            return;
        }
        // ---------------------------------------------------
        // 만약 중복되어 있으면 경고하고 함수 중단.
        // ---------------------------------------------------
        if(names!=null){

            // 반복문 돌려서 비교하는것은 주석처리
            // for(let i = 0; i<names.length; i++){
            //     // alert(names[i].text)
            //     // alert(inputText)
            //     if( inputText == names[i].text ){
            //         alert("중복은 입력안됩니다.")
            //         setInputText("");
            //         return;
            //     }
            // } 

            // ----------------------------------------
            // 지역변수 tmpNames 선언하고
            // Array 객체의 filter 메소드를 호출하여
            // names 에 저장된 사용정객체를 1개씩 꺼내서
            // 아래의 화살표 함수를 호출하여 리턴되는 데이터가 true 일때만
            // 기존 사용자정의 객체만 복사해 누적하기  
            // ----------------------------------------
            const tmpNames = names.filter(name=>name.text===inputText);
            if( tmpNames.length>0 ){
                alert( "\""+ inputText + "\"" + " 문자는 이미 있어 입력이 불가능!");
                setInputText("");

                // -----------------------------------------
                // ref={nameRef} 가진 태그에 포커스 들여놓기
                // -----------------------------------------
                nameRef.current.focus();
                return;
            }
        }



        // ----★이 프로그램의 키포인트 소스★----------------
        // 지역변수 newNames 선언하고 
        // names 안의 Array 객체 복사하고 {id : nextId, text : inputText} 추가하고 
        // 이렇게 만들어 새로운 Array 객체를 newNames 에 저장하기   
        // ---------------------------------------------------
        const newNames = names.concat({
            id : nextId         // nextId 값을 id 로 설정하고
            ,text : inputText
        });
        // ---------------------------------------------------
        // newNames 안의 Array 객체를 기존 names 안에 갱신해서 저장하기 
        // ---------------------------------------------------
        setNames( newNames );
        // ---------------------------------------------------
        // nextId 지역변수에 nextId+1 의 실행 결과 저장하기. 
        // 즉, 기존 데이터에서 1 증가하란 의미 
        // ---------------------------------------------------
        setNextId( nextId+1 );
        // ---------------------------------------------------
        // inputText 지역변수에 "" 저장하기.
        // 즉, 결국 입력양식이 비어지게 된다.   
        // ---------------------------------------------------
        setInputText("");

        // 포커스 들여 놓기.
        // -----------------------------------------
        // ref={nameRef} 가진 태그에 포커스 들여놓기
        // -----------------------------------------
        nameRef.current.focus();
    };


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 화살표함수가 저장된 지역변수 remove 선언.
    // 화살표함수 안에는 목록을 더블클릭하면 목록을 삭제하는 구문이 내포되어 있다.    
    // 매개변수 더블클릭하는 목록의 고유값인 id 값이 들어 온다.  
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const remove = (id)=> {
        //---------------------------------------------------
        // 지역변수 nextNames 선언하고
        // Array 객체의 filter 메소드를 호출하여
        // names 에 저장된 사용정객체를 1개씩 꺼내서
        // 아래의 화살표 함수를 호출하여 리턴되는 데이터가 true 일때만
        // 사용자정의 객체만 복사해 누적하기  
        // 매개변수로 들어온 id 와 같지 않은 것만 골라서 누적하기
        //---------------------------------------------------
        const nextNames =  names.filter((name) => name.id !== id);
        //---------------------------------------------------
        // names 지역변수에 nextNames 안의 Array 객체로 갱신하기.
        //---------------------------------------------------
        setNames( nextNames );

    };


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // 지역변수 namesTag 선언하고
    // Array 객체의 map 메소드를 호출하여
    // names 에 저장된 사용정객체를 1개씩 꺼내서
    // 아래의 화살표 함수를 호출하여 리턴되는 html 코딩을 누적해 저장하기   
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const namesTag = names.map(
        name => 
            <li style={{cursor:'pointer'}} key={name.id} onDoubleClick={()=>remove(name.id)}>
                {name.text}
            </li>
    );

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // JSX 문법을 가진 return 구문 선언  
    // 리턴되는 JSX 문법이 웹화면에 출력된다.     
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    return(
        <>
        <center>
            <br/>
            <table><tr><td>

            <input 
                type='text' 
                ref={nameRef}
                value={inputText}       // value 속성값으로 지역변수 inputText 안의 데이터 삽입하기
                onChange={textChange}   // 입력값이 바뀌면, 즉, 키보드로 데이터를 입력하면 
                                        // textChange 변수안의 화살표함수 호출하기
            />&nbsp;

            <button 
                onClick={add}           // 버튼 클릭하면 add 변수안의 화살표 함수 호출하기
            >추가</button>

            <ul>{namesTag}</ul>

            </td></tr></table>
        </center>
        </>
    )
};
export default RegData;
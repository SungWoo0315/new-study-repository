// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명 /node_modules/react 안에 default 가 붙어 수출하는 놈을 수입해서 현재 파일에서 변수 React 에 저장하기
// 프로젝트명 /node_modules/react 안에 default 가 안 붙어 수출하는 useState 함수를 수입해서 현재 파일에서 변수 useState 에 저장하기
// ---------------------------------------------------------------
// <참고> 함수 컴포넌트를 선언할 경우 대부분 useState 함수를 사용한다.
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { useState, useRef } from 'react';

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
const Search = () => {


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [developers, setDevelopers] = useState(
        [
            { dev_no : 1, dev_name : '사오정', addr : '서울시', phone : '010-1111-2222'}
            ,{ dev_no : 2, dev_name : '저팔계', addr : '제주시', phone : '010-2222-1212'}
            ,{ dev_no : 3, dev_name : '손오공', addr : '대구시', phone : '010-3333-2323'}
            ,{ dev_no : 4, dev_name : '삼장법사', addr : '부산시', phone : '010-4444-3434'}
            ,{ dev_no : 5, dev_name : '우마왕', addr : '김해시', phone : '010-5555-4545'}
            ,{ dev_no : 6, dev_name : '홍길동', addr : '전주시', phone : '010-6666-5656'}
            ,{ dev_no : 7, dev_name : '고길동', addr : '경주시', phone : '010-7777-6767'}
            ,{ dev_no : 8, dev_name : '정다운', addr : '서울시', phone : '010-8888-9922'}
            ,{ dev_no : 9, dev_name : '한국남', addr : '대구시', phone : '010-8872-1027'}
            ,{ dev_no : 10, dev_name : '둘리', addr : '서울시', phone : '010-4330-7819'}
            ,{ dev_no : 11, dev_name : '코난', addr : '제주시', phone : '010-6764-8021'}
            ,{ dev_no : 12, dev_name : '도우너', addr : '세종시', phone : '010-1263-5772'}
        ]
    );
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm


    const [inputText, setInputText] = useState('');


    const textChange = (e) => {
        
        let val = e.target.value;

        val = val.trim();
       
        setInputText(val);
    }

    const keyPress = e => {
        if ( e.key === 'Enter' ){
            dev_search();
        }
    }

    const dev_search = () => {
        // ---------------------------------------------------
        // 만약 입력한 데이터가 비어있으면 경고하고 함수 중단.
        // ---------------------------------------------------
        if(inputText==null || inputText==undefined || inputText=='' || inputText.split(" ").join("")==''){
            alert("길이없는 데이터는 검색이 안됩니다. \n안돼! 돌아가!")
            setInputText("");

            // -----------------------------------------
            // ref={nameRef} 가진 태그에 포커스 들여놓기
            // -----------------------------------------
            // nameRef.current.focus();
            return;
        }
        // ---------------------------------------------------
        // 만약 중복되어 있으면 경고하고 함수 중단.
        // ---------------------------------------------------
        if(developers!=null){

            // 반복문 돌려서 비교하는것은 주석처리
            // for(let i = 0; i<names.length; i++){
            //     // alert(names[i].text)
            //     // alert(inputText)
            //     if( inputText == names[i].text ){
            //         alert("중복은 입력안됩니다.")
            //         setInputText("");
            //         return;
            //     }
            // } 

            // ----------------------------------------
            // 지역변수 tmpNames 선언하고
            // Array 객체의 filter 메소드를 호출하여
            // names 에 저장된 사용정객체를 1개씩 꺼내서
            // 아래의 화살표 함수를 호출하여 리턴되는 데이터가 true 일때만
            // 기존 사용자정의 객체만 복사해 누적하기  
            // ----------------------------------------
            const devNames = developers.filter(developer=>developer.dev_name.includes(inputText));
            if( devNames.length>0 ){
                // alert( "\""+ inputText + "\"" + " 문자는 이미 있어 입력이 불가능!");
                setInputText("");
                setDevelopers(devNames);
                // -----------------------------------------
                // ref={nameRef} 가진 태그에 포커스 들여놓기
                // -----------------------------------------
                // nameRef.current.focus();
                
            }
            const devAddr = developers.filter(developer=>developer.addr.includes(inputText));
            if( devAddr.length>0 ){
                // alert( "\""+ inputText + "\"" + " 문자는 이미 있어 입력이 불가능!");
                setInputText("");
                setDevelopers(devAddr);
                // -----------------------------------------
                // ref={nameRef} 가진 태그에 포커스 들여놓기
                // -----------------------------------------
                // nameRef.current.focus();
                
            }            
            const devPhone = developers.filter(developer=>developer.phone.includes(inputText));
            if( devPhone.length>0 ){
                // alert( "\""+ inputText + "\"" + " 문자는 이미 있어 입력이 불가능!");
                setInputText("");
                setDevelopers(devPhone);
                // -----------------------------------------
                // ref={nameRef} 가진 태그에 포커스 들여놓기
                // -----------------------------------------
                // nameRef.current.focus();
                
            }
        }



        // ----★이 프로그램의 키포인트 소스★----------------
        // 지역변수 newNames 선언하고 
        // names 안의 Array 객체 복사하고 {id : nextId, text : inputText} 추가하고 
        // 이렇게 만들어 새로운 Array 객체를 newNames 에 저장하기   
        // ---------------------------------------------------
        // const newNames = developers.concat({
        //     id : nextId         // nextId 값을 id 로 설정하고
        //     ,text : inputText
        // });
        // ---------------------------------------------------
        // newNames 안의 Array 객체를 기존 names 안에 갱신해서 저장하기 
        // ---------------------------------------------------
        // setNames( newNames );
        // ---------------------------------------------------
        // nextId 지역변수에 nextId+1 의 실행 결과 저장하기. 
        // 즉, 기존 데이터에서 1 증가하란 의미 
        // ---------------------------------------------------
        // setNextId( nextId+1 );
        // ---------------------------------------------------
        // inputText 지역변수에 "" 저장하기.
        // 즉, 결국 입력양식이 비어지게 된다.   
        // ---------------------------------------------------
        setInputText("");

        // 포커스 들여 놓기.
        // -----------------------------------------
        // ref={nameRef} 가진 태그에 포커스 들여놓기
        // -----------------------------------------
        // nameRef.current.focus();
    };
   
    const dev_search_all = () => {
        
        var xxx =  [
            { dev_no : 1, dev_name : '사오정', addr : '서울시', phone : '010-1111-2222'}
            ,{ dev_no : 2, dev_name : '저팔계', addr : '제주시', phone : '010-2222-1212'}
            ,{ dev_no : 3, dev_name : '손오공', addr : '대구시', phone : '010-3333-2323'}
            ,{ dev_no : 4, dev_name : '삼장법사', addr : '부산시', phone : '010-4444-3434'}
            ,{ dev_no : 5, dev_name : '우마왕', addr : '김해시', phone : '010-5555-4545'}
            ,{ dev_no : 6, dev_name : '홍길동', addr : '전주시', phone : '010-6666-5656'}
            ,{ dev_no : 7, dev_name : '고길동', addr : '경주시', phone : '010-7777-6767'}
            ,{ dev_no : 8, dev_name : '정다운', addr : '서울시', phone : '010-8888-9922'}
            ,{ dev_no : 9, dev_name : '한국남', addr : '대구시', phone : '010-8872-1027'}
            ,{ dev_no : 10, dev_name : '둘리', addr : '서울시', phone : '010-4330-7819'}
            ,{ dev_no : 11, dev_name : '코난', addr : '제주시', phone : '010-6764-8021'}
            ,{ dev_no : 12, dev_name : '도우너', addr : '세종시', phone : '010-1263-5772'}
        ]
        setDevelopers(xxx);

        // setDevelopers(developers);
        
        setInputText("");
    };


    const developersTag = developers.map(

        developer => 
                <tr key={developer.dev_no}>
                    <td>{developer.dev_no}</td>
                    <td>{developer.dev_name}</td>
                    <td>{developer.addr}</td>
                    <td>{developer.phone}</td>
                </tr>
    );

    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    // JSX 문법을 가진 return 구문 선언  
    // 리턴되는 JSX 문법이 웹화면에 출력된다.     
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    return(
        <>
            <center>
            {inputText}
                <br/>
                [키워드] : <input 
                    type='text' 
                    value={inputText}  
                    onKeyPress={keyPress}   
                    onChange={textChange}  
                />
                &nbsp;
                <button 
                    onClick={dev_search}           
                >검색</button>
                &nbsp;&nbsp;
                <button 
                    onClick={dev_search_all}           
                >모두검색</button>

                <br/><br/>

                <table border="1" cellPadding="5" cellspacing="0">
                    <caption>총 {developers.length} 명</caption>
                    <th bgcolor="gray" width="50px">번호</th>
                    <th bgcolor="gray" width="100px">직원명</th>
                    <th bgcolor="gray" width="80px">거주지</th>
                    <th bgcolor="gray" width="150px">전화번호</th>
                    {developersTag}
                </table>
            </center>
        </>
    )
};
export default Search;
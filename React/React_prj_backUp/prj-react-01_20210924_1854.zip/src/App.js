import logo from './logo.svg';
import './App.css';

import React, {Component} from 'react';
import { Route } from 'react-router-dom';
import Test from './naver/Test';

function App() {
  return (
    <div>
      <Route path="/naver/test" component={Test}></Route>
    </div>
    // <>
    // <div className="App">
    //   <header className="App-header">

    //   {/* --------------------------------------------  */}
    //   {/* 주석처리 */}
    //   {/* --------------------------------------------  */}
    //   안녕하세요 React 입니다!....<br/>
    //   하하하하핳...
    //   hahaha<br/>
    //   겨우 들어왔다...
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // <div>

    // </div>  
    // </div>
    // </>
  );
}

export default App;

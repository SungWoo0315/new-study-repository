// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 프로젝트명 /node_modules/react 안에 default 가 붙어 수출하는 놈을 수입해서
    // 현재 파일 안에서 React 란 이름으로 사용!
// 프로젝트명 /node_modules/react 안에 default 가 안 붙어 수출하는 놈 useState 을 수입해서
    // 현재 파일 안에서 useState 란 이름으로 사용!
// ---------------------------------------------------------------
// <참고> 아래 수입 코드는 함수 컴포넌트가 선언되는 js 파일 안에서는 필수로 수입되는 놈들이다.
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
import React, { useState } from 'react';

// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// 리액트의 단위 프로그램 중 하나인 [함수 컴포넌트] 선언하기
// MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
const RegData = () => {
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [names, setNames] = useState(
        [
            { id : 1, text : '사오정'}
            ,{ id : 2, text : '저팔계'}
            ,{ id : 3, text : '손오공'}
            ,{ id : 4, text : '삼장법사'}
            ,{ id : 5, text : '우마왕'}
        ]
    );
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [inputText, setInputText] = useState('');
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const [nextId, setNextId] = useState(names.length+1);
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const textChange = (e) => {
        setInputText(e.target.value);
    }
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const add = () => {

        // 만약 중복되어 있으면 경고하고 함수 중단.
        for(var i = 0; i<names.length; i++){
            // alert(names[i].text)
            // alert(inputText)
            if( inputText == names[i].text ){
                alert("중복은 입력안됩니다.")
                return;
            }
        } 

        // 만약 비어있으면 경고하고 함수 중단.
        // 공백이나 길이가 없는데이터 걸러내는코드 내가만들어봄
        if(inputText=='' || inputText.split(" ").join("")==''){
            alert("길이없는 데이터는 안됩니다.")
            return;
        }


        const newNames = names.concat({
            id : nextId         // nextId 값을 id 로 설정하고
            ,text : inputText
        });
        setNextId( nextId+1 );
        setNames( newNames )
    };
    const onRemove = (id)=> {
        
        // 매개변수로 들어온 id 를 가진 놈을 삭제한 후 재 저장
        setNames(names.filter((name) => name.id !== id));

    };


    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    const namesTag = names.map(
        name => 
            <li style={{cursor:'pointer'}} key={name.id} onDoubleClick={()=>onRemove(name.id)}>
                {name.text}
            </li>
    );
    // mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
    return(
        <>
        <center>
            <br/>
            <table><tr><td>

            <input type='text' value={inputText} onChange={textChange}/>&nbsp;
            <button onClick={add}>추가</button>
            <ul>{namesTag}</ul>

            </td></tr></table>
        </center>
        </>
    )
};
export default RegData;
package com.naver.erp;


public class BoardSearchDTO {        
	
	private String keyword1;

	
	
	
	public String getKeyword1() {
		return keyword1;
	}

	public void setKeyword1(String keyword1) {
		this.keyword1 = keyword1;
	}
    

}

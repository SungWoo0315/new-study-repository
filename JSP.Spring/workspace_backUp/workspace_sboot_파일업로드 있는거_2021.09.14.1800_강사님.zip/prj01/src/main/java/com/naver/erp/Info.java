package com.naver.erp;


public interface Info {    

	// <주의> 운영체제 경로가 문자열이므로 \  를 \\ 로 써야함. \\ 대신에 / 쓰지 말것.
	public static String board_pic_dir 
		= "C:\\zzz\\workspace_sboot_파일업로드 있는거_2021.09.13.1811\\prj01\\src\\main\\resources\\static\\resources\\img\\";

	public static String naverPath = "naver/";
}






























package com.naver.erp;

public interface EmpService {

	int updateEmp(EmpDTO empDTO);

	int deleteEmp(EmpDTO empDTO);

	int insertEmp(EmpDTO empDTO);

}

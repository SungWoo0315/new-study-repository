package com.naver.erp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj01Application {

	public static void main(String[] args) {
		SpringApplication.run(Prj01Application.class, args);
	}

}

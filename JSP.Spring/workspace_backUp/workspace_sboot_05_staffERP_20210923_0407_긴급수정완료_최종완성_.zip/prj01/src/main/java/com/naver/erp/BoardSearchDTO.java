package com.naver.erp;

import java.util.List;

public class BoardSearchDTO {

	// -------------------------------------------------
	// [검색 키워드] 저장하는 속성변수 선언
	// 현재 [선택된 페이지 번호]를 저장하는 속성변수 선언.
	// 한 화면에 보여줄 [행의 개수]를 저장하는 속성변수 선언.
	// -------------------------------------------------
	private String keyword1;


	private int selectPageNo = 0;
	private int rowCntPerPage = 10;
	
	// private String[] day;  // 배열로 받을수 있다. 아래코드와 이 코드 방식 두가지로 체크박스를 담을 수 있다.  
	private List<String> jikup;
	private List<String> dep_name;

	// private String sex;
	private List<String> sex;


	private int religion_code;
	// private int school_code;
	private List<String> school_code;

	// private String graduate_day; // 아래쪽에 연도월 뽑는게있음.


	private List<String> skill_code;

	private String startYearMonth;
	private String endYearMonth;

	private String sort;

	private String start_year;
	private String end_year;
	
	
	
	// -------------------------------------------------
	// getter, setter 메소드 선언
	// -------------------------------------------------

	public String getKeyword1() {
		return keyword1;
	}
	public void setKeyword1(String keyword1) {
		this.keyword1 = keyword1;
	}
	public int getSelectPageNo() {
		return selectPageNo;
	}
	public void setSelectPageNo(int selectPageNo) {
		this.selectPageNo = selectPageNo;
	}
	public int getRowCntPerPage() {
		return rowCntPerPage;
	}
	public void setRowCntPerPage(int rowCntPerPage) {
		this.rowCntPerPage = rowCntPerPage;
	}
	public List<String> getJikup() {
		return jikup;
	}
	public void setJikup(List<String> jikup) {
		this.jikup = jikup;
	}
	public List<String> getDep_name() {
		return dep_name;
	}
	public void setDep_name(List<String> dep_name) {
		this.dep_name = dep_name;
	}
	public String getStartYearMonth() {
		return startYearMonth;
	}
	public void setStartYearMonth(String startYearMonth) {
		this.startYearMonth = startYearMonth;
	}
	public String getEndYearMonth() {
		return endYearMonth;
	}
	public void setEndYearMonth(String endYearMonth) {
		this.endYearMonth = endYearMonth;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getStart_year() {
		return start_year;
	}
	public void setStart_year(String start_year) {
		this.start_year = start_year;
	}
	public String getEnd_year() {
		return end_year;
	}
	public void setEnd_year(String end_year) {
		this.end_year = end_year;
	}
	
	
	// public String getSex() {
	// 	return sex;
	// }
	// public void setSex(String sex) {
	// 	this.sex = sex;
	// }
	
	
	
	public int getReligion_code() {
		return religion_code;
	}
	public void setReligion_code(int religion_code) {
		this.religion_code = religion_code;
	}
	
	
	
	// public int getSchool_code() {
	// 	return school_code;
	// }
	// public void setSchool_code(int school_code) {
	// 	this.school_code = school_code;
	// }
	
	
	
	public List<String> getSkill_code() {
		return skill_code;
	}
	
	
	
	public void setSkill_code(List<String> skill_code) {
		this.skill_code = skill_code;
	}
	public List<String> getSchool_code() {
		return school_code;
	}
	public void setSchool_code(List<String> school_code) {
		this.school_code = school_code;
	}
	
	
	
	public List<String> getSex() {
		return sex;
	}
	public void setSex(List<String> sex) {
		this.sex = sex;
	}
	
	
	// public String getGraduate_day() {
	// 	return graduate_day;
	// }
	// public void setGraduate_day(String graduate_day) {
	// 	this.graduate_day = graduate_day;
	// }
	
	
	
	
	
	
	
	
	



	
	
	

	
	
	
	
	




	
	



    
}

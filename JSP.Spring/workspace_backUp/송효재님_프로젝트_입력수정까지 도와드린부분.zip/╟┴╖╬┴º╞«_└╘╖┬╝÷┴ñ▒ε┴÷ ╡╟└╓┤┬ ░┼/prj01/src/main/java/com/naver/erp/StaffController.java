package com.naver.erp;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
// URL 주소로 접속하면 호출되는 메소드를 소유한 [컨트롤러 클래스] 선언
// @Controller 를 붙임으로써 [컨트롤러 클래스]임을 지정한다.
//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
@Controller
public class StaffController {

	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// 속성변수 boardService 선언하고 [BoardService 인터페이스]를 구현한 클래스를 찾아 객체 생성해 객체의 메위주를 저장.
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
		// @Autowired 역할 -> 속성변수에 붙은 자료형인 [인터페이스]를 구현한 클래스를 찾아 객체 생성해 객체의 메위주를 저장.
		// [인터페이스]를 구현한 [클래스]가 1개가 아니면 에러가 발생한다.
		// 단 @Autowired( required=flase ) 로 선언하면 [인터페이스]를 구현한 [클래스]가 0개 이어도 에러없이 null 이 저장된다. 
	@Autowired
	private StaffService staffService;
	
	
	
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
	// 속성변수 boardDAO 선언하고 [BoardDAO 인터페이스]를 구현한 클래스를 찾아 객체 생성해 객체의 메위주를 저장.
	//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN	
	@Autowired
	private StaffDAO staffDAO;
	
	
	
	
	@RequestMapping( value="/staff_search_Form.do" )
	public ModelAndView getStaffList(
			
		){
		
		//**************************************************
		// Oracle(오라클) board 테이블 안의 데이터를 검색해와 자바 객체에 저장하기. 즉 [ 게시판 목록 ] 얻기
		//**************************************************
		List<Map<String,String>> staffList = this.staffDAO.getStaffList();
		
		
		
		
		//----------------------------------
		// [ModelAndView 객체] 생성하기
		// [ModelAndView 객체] 에 [호출 JSP 페이지명]을 저장하기
		//----------------------------------		
		ModelAndView mav = new ModelAndView( );
		mav.setViewName("staff_search_Form.jsp");
		//----------------------------------
		// [ModelAndView 객체]에 [ 게시판 목록 검색 결과 ]를 저장하기
		//----------------------------------
		mav.addObject("staffList", staffList);
	//	mav.addObject("staffListAllCnt", staffListAllCnt)
		//----------------------------------		
		// [ModelAndView 객체] 리턴하기
		//----------------------------------		
		return mav;			
	}

//-----------------------------------------------------------------------------------------------------------------	
	
	
	
	
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 가상주소 /boardRegForm.do 로 접근하면 호출되는 메소드 선언
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@RequestMapping( value="/staff_input_Form.do")
	public ModelAndView goStaff_input_Form( ) {

		List<String> ReligionList = this.staffDAO.getReligionList();
		List<String> SchoolList = this.staffDAO.getSchoolList();
		List<String> SkillList = this.staffDAO.getSkillList();
		

		
		//*******************************************
		// [ModelAndView 객체] 생성하기
		//*******************************************
		ModelAndView mav = new ModelAndView( );
		//*******************************************
		// [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
		//*******************************************
		mav.setViewName("staff_input_Form.jsp");
		
		
		mav.addObject("ReligionList", ReligionList);	
		mav.addObject("SchoolList", SchoolList);
		mav.addObject("SkillList", SkillList);
		
		//*******************************************
		// [ModelAndView 객체] 리턴하기
		//*******************************************
		return mav;

	}





	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// /boardRegProc.do 로 접근하면 호출되는 메소드 선언하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@RequestMapping( value="/staff_input_Proc.do")
	public  ModelAndView insertStaff( 
			//*******************************************
			// 파라미터값을 저장할 [BoardDTO 객체]를 매개변수로 선언
			//*******************************************
				// [파라미터명]과 [BoardDTO 객체]의 [속성변수명]이 같으면
				// setter 메소드가 작동되어 [파라미터값]이 [속성변수]에 저장된다.
				// [속성변수명]에 대응하는 [파라미터명]이 없으면 setter 메소드가 작동되지 않는다.
				// [속성변수명]에 대응하는 [파라미터명]이 있는데 [파라미터값]이 없으면
				// [속성변수]의 자료형에 관계없이 무조건 null 값이 저장된다.
				// 이때 [속성변수]의 자료형이 기본형일 경우 null 값이 저장될 수 없어 에러가 발생한다.
				// 이런 에러를 피하려면 파라미터값이 기본형이거나 속성변수의 자료형을 String으로 해야한다.
				// 이런 에러가 발생하면 메소드안의 실행구문은 하나도 실행되지 않음에 주의한다.
				// 매개변수로 들어온 [DTO 객체]는 이 메소드가 끝난 후 호출되는 JSP 페이지로 그대로 이동한다.
				// 즉, HttpServletRequest 객체에 boardDTO 라는 키값명으로 저장된다.
			StaffDTO staffDTO
			//*******************************************
			// Error 객체를 관리하는 BindingResult 객체가 저장되어 들어오는 매개변수 bindingResult 선언
			//*******************************************
			, BindingResult bindingResult
	){
		ModelAndView mav = new ModelAndView( );
		mav.setViewName("staff_input_Proc.jsp");
		try {
			System.out.println( staffDTO.getStaff_no() );
			System.out.println( staffDTO.getStaff_name() );
			System.out.println( staffDTO.getJumin_no1() );
			System.out.println( staffDTO.getJumin_no2() );
			System.out.println( staffDTO.getReligion_code() );
			System.out.println( staffDTO.getSchool_code() );
			System.out.println( staffDTO.getStaff_skill_insert() );
			System.out.println( staffDTO.getGraduation_year() );
			System.out.println( staffDTO.getGraduation_month() );
			
			
			//*******************************************
			// check_StaffDTO 메소드를 호출하여 [유효성 체크]하고 경고 문자 얻기
			//*******************************************
			// 유효성 체크 에러 메시지 저장할 변수 msg 선언
			String msg = "";
			// check_StaffDTO 메소드를 호출하여 유효성 체크하고 에러 메시지 문자 얻기
			msg = check_StaffDTO( staffDTO , bindingResult  );
			// [ModelAndView 객체]에 [유효성 체크 에러 메시지] 저장하기
			mav.addObject("msg", msg);
			
			
			System.out.println( "컨트롤러에서 msg 확인."+msg );
			System.out.println( "에러메시지 확인 "+bindingResult.hasErrors() );
			
			// 만약 msg 안에 "" 가 저장되어 있으면, 즉 유효성 체크를 통과했으면
			if( msg.equals("") ){			
				//*******************************************
				// [BoardServiceImpl 객체]의 insertBoard 메소드 호출로 
				// 게시판 글 입력하고 [게시판 입력 적용행의 개수] 얻기
				//*******************************************
				System.out.println( "여기 아래서 부터 작동 안됌." );
				int staff_intput_Cnt = this.staffService.insertStaff(staffDTO);
				System.out.println( "작동 완료 >>>>>>>>>>>>>>>>." );
				int staff_skill_insert = this.staffService.insertSkillList(staffDTO);
				// DB 연동 됐는지 확인용.
				System.out.println("staff_intput_Cnt => "+ staff_intput_Cnt); // DB연동 성공했는지 확인
				//*******************************************
				// [ModelAndView 객체]에 [게시판 수정 적용행의 개수] 저장하기
				//*******************************************
				mav.addObject("staff_intput_Cnt", staff_intput_Cnt);
			}
			// 만약 msg 안에 "" 가 저장되어 있지 않으면, 즉 유효성 체크를 통과못했으면
			else{
				mav.addObject("staff_intput_Cnt", 0 );
			}
			//*******************************************
			// [ModelAndView 객체] 리턴하기
			//*******************************************
			System.out.println( "StaffController.insertStaff 메소드 호출 성공 " );
		}catch(Exception ex) {
			mav.addObject("staff_intput_Cnt", -1);
			mav.addObject("msg", "서버에서 문제 발생! 서버 관리자에게 문의 바람" );
		}
		return mav;

	}


	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// 게시판 입력 또는 수정 시 게시판 입력글의 입력양식의 유효성을 검사하고 
	// 문제가 있으면 경고 문자를 리턴하는 메소드 선언.
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	public String check_StaffDTO( StaffDTO staffDTO, BindingResult bindingResult ){
		String checkMsg = "";
		//*******************************************
		// BoardDTO 객체에 저장된 데이터의 유효성 체크할 BoardValidator 객체 생성하기
		// BoardValidator 객체의 validate 메소드 호출하여 유효성 체크 실행하기.
		//*******************************************
		StaffValidator staffValidator = new StaffValidator();
		staffValidator.validate(
				staffDTO           // 유효성 체크할 DTO 객체
				, bindingResult    // 유효성 체크 결과를 관리하는 BindingResult 객체
		);
		//*******************************************
		// 만약 BindingResult 객체의 hasErrors() 메소드 호출하여 true 값을 얻으면
		//*******************************************
		if( bindingResult.hasErrors() ) {
			// 변수 checkMsg 에 BoardValidator 객체에 저장된 경고문구 얻어 저장하기
			checkMsg = bindingResult.getFieldError().getCode();
		}
		//*******************************************
		// checkMsg 안의 문자 리턴하기
		//*******************************************
		return checkMsg;
	}
	
	
	

	
	
//----------------------------------------------------------------------------------------------------------------	
	
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// /boardUpDelForm.do 접속 시 호출되는 메소드 선언
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@RequestMapping(value="staff_UpDel_Form.do" )
	public ModelAndView goStaffUpDelForm( 
			//---------------------------------------
			// "b_no" 라는 파라미터명의 파라미터값이 저장되는 매개변수 b_no 선언
			// 수정 또는 삭제할 게시판 고유 번호가 들어오는 매개변수선언
			//---------------------------------------
			@RequestParam(value="staff_no") int staff_no
	){
		//*******************************************
		// boardDAOImpl 객체의 getBoard 메소드 호출로 
		// 1개의 게시판글을 BoardDTO 객체에 담아서 가져오기
		//*******************************************
		StaffDTO staffDTO = this.staffDAO.getStaff(staff_no);
		//*******************************************
		// [ModelAndView 객체] 생성하기
		// [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
		// [ModelAndView 객체]에 [수정/삭제할 1개의 게시판 글 정보] 저장하기
		// [ModelAndView 객체] 리턴하기
		//*******************************************
		ModelAndView mav = new ModelAndView( );
		mav.setViewName("staff_UpDel_Form.jsp");
		mav.addObject("staffDTO",staffDTO);
		return mav;

	}

/*

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	// /boardUpDelProc.do 접속 시 호출되는 메소드 선언
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@RequestMapping(value="/staff_UpDel_Proc.do")
	public ModelAndView staff_UpDel_Proc(
			//*******************************************
			// 파라미터값을 저장할 [BoardDTO 객체]를 매개변수로 선언
			//*******************************************
			StaffDTO staffDTO
			//*******************************************
			// "upDel" 라는 파라미터명의 파라미터값이 저장된 매개변수 b_no 선언
			//*******************************************
			,@RequestParam(value="upDel") String upDel
			//*******************************************
			// 유효성 검사 결과를 관리하는 BindingResult 객체가 저장되어 들어오는 
			// 매개변수 bindingResult 선언
			//*******************************************
			, BindingResult bindingResult
	){
			//*******************************************
			// [ModelAndView 객체] 생성하기
			// [ModelAndView 객체]에 [호출 JSP 페이지명]을 저장하기
			// [ModelAndView 객체]에 [수정/삭제할 1개의 게시판 글 정보] 저장하기
			// [ModelAndView 객체] 리턴하기
			//*******************************************
			ModelAndView mav = new ModelAndView( );
			mav.setViewName("staff_UpDel_Proc.jsp");

			//*******************************************
			// 만약 게시판 삭제 모드이면
			//*******************************************
			if( upDel.equals("del") ){
				// 삭제 실행하고 삭제 적용행의 개수얻기
				int staffUpDelCnt = this.staffService.deleteStaff(staffDTO);
				mav.addObject("staffUpDelCnt", staffUpDelCnt );
			}
			//*******************************************
			// 만약게시판  수정 모드이면 수정 실행하고 수정 적용행의 개수얻기
			//*******************************************
			else if(upDel.equals("up")) {
				//*******************************************
				// check_BoardDTO 메소드를 호출하여 [유효성 체크]하고 경고 문자 얻기
				//*******************************************
				// 유효성 체크 에러 메시지 저장할 변수 msg 선언
				String msg = "";
				// check_BoardDTO 메소드를 호출하여 유효성 체크하고 에러 메시지 문자 얻기
				msg = check_StaffDTO( staffDTO , bindingResult  );
				// ModelAndView 객체에 유효성 체크 시 발생한 에러 메시지 저장하기
				mav.addObject("msg", msg );
				// 만약 msg 안에 "" 가 저장되어 있으면, 즉 유효성 체크를 통과했으면
				if( msg.equals("") ){		
					//----------------------------------------
					// BoardServiceImple 객체의 updateBoard 라는 메소드 호출로
					// 게시판 수정 실행하고 수정 적용행의 개수얻기
					//---------------------------------------- 
					int staffUpDelCnt = this.staffService.updateStaff(staffDTO);
					//---------------------------------------- 
					// ModelAndView 객체에  수정 적용행의 개수 저장하기
					//---------------------------------------- 
					mav.addObject("staffUpDelCnt", staffUpDelCnt );
				}
				// 만약 msg 안에 "" 가 저장되어 있지 않으면, 즉 유효성 체크를 통과못했으면
				else{
					mav.addObject("staffUpDelCnt", 0);
				}
			}
			return mav;
	}

}
*/
}

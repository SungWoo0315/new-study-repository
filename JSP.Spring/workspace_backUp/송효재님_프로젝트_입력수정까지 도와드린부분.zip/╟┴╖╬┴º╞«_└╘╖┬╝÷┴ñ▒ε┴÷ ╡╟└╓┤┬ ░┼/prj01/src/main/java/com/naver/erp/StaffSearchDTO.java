package com.naver.erp;

import java.util.List;
import java.util.Map;

public class StaffSearchDTO {
	private String keyword;
	private List<String> gender;
	private String religion;
	private List<String> achievement;
	private List<String> skill;
	private String graduate_year_min;
	private String graduate_month_min;
	private String graduate_year_max;
	private String graduate_month_max;
//---------------------------------------------------------------------------
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public List<String> getGender() {
		return gender;
	}
	public void setGender(List<String> gender) {
		this.gender = gender;
	}
	public String getReligion() {
		return religion;
	}
	public void setReligion(String religion) {
		this.religion = religion;
	}
	public List<String> getAchievement() {
		return achievement;
	}
	public void setAchievement(List<String> achievement) {
		this.achievement = achievement;
	}
	public List<String> getSkill() {
		return skill;
	}
	public void setSkill(List<String> skill) {
		this.skill = skill;
	}
	public String getGraduate_year_min() {
		return graduate_year_min;
	}
	public void setGraduate_year_min(String graduate_year_min) {
		this.graduate_year_min = graduate_year_min;
	}
	public String getGraduate_month_min() {
		return graduate_month_min;
	}
	public void setGraduate_month_min(String graduate_month_min) {
		this.graduate_month_min = graduate_month_min;
	}
	public String getGraduate_year_max() {
		return graduate_year_max;
	}
	public void setGraduate_year_max(String graduate_year_max) {
		this.graduate_year_max = graduate_year_max;
	}
	public String getGraduate_month_max() {
		return graduate_month_max;
	}
	public void setGraduate_month_max(String graduate_month_max) {
		this.graduate_month_max = graduate_month_max;
	}

}











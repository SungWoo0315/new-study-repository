package com.naver.erp;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.text.SimpleDateFormat;
import java.util.regex.Pattern;


//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
// BoardDTO 객체에 저장된 데이터의 유효성 체크할 BoardValidator 클래스 선언하기
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
public class BoardValidator implements Validator {

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//  유효성 체크할 객체의 클래스 타입 정보 얻어 리턴하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@Override
	public boolean supports(Class<?> arg0) {
		return BoardDTO.class.isAssignableFrom(arg0);  // 검증할 객체의 클래스 타입 정보
	}

	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	//  유효성 체크할 메소드 선언하기
	//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
	@Override
	public void validate(
		Object obj          // DTO 객체 저장 매개변수
		, Errors errors     // 유효성 검사 시 발생하는 에러를 관리하는 Errors 객체 저장 매개변수
	){
		try {
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// 유효성 체크할 DTO 객체 얻기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			BoardDTO dto = (BoardDTO)obj;

			//        String sWriter = dto.getWriter();
			//        if(sWriter == null || sWriter.trim().isEmpty()) {
			//            System.out.println("Writer is null or empty");
			//            errors.rejectValue("writer", "trouble");
			//        }


			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils 클래스의 rejectIfEmptyOrWhitespace 메소드 호출하여
			//		BoardDTO 객체의 속성변수명 writer 이 비거나 공백으로 구성되어 있으면
			//		경고 메시지를 Errors 객체에 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			ValidationUtils.rejectIfEmptyOrWhitespace(
				errors                       // Errors 객체
				, "staff_name"                   // BoardDTO 객체의 속성변수명
				, "사원 이름 입력요망"        // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			);
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// BoardDTO 객체의 속성변수명 "writer" 저장된 데이터의 길이가 10자 보다 크면
			// Errors 객체에 속성변수명 "writer" 과 경고 메시지 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			String staff_name = dto.getStaff_name();
			if( Pattern.matches("^[가-힣]{1,4}$", staff_name)==false ) {
				errors.rejectValue("staff_name", "사원이름은 한글만 가능합니다. \r이름의 최대 글자수는 \"4\" 입니다.");
			};
			// if( staff_name!=null && staff_name.length() >10) {
			// 	errors.rejectValue("staff_name", "사원명 공백없이 10자이하 입니다.");
			// }

			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils 클래스의 rejectIfEmptyOrWhitespace 메소드 호출하여
			//		BoardDTO 객체의 속성변수명 writer 이 비거나 공백으로 구성되어 있으면
			//		경고 메시지를 Errors 객체에 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils.rejectIfEmptyOrWhitespace(
			// 	errors                       // Errors 객체
			// 	, "salary"                   // BoardDTO 객체의 속성변수명
			// 	, "연봉 입력요망"         // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			// );
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// BoardDTO 객체의 속성변수명 "subject" 저장된 데이터의 길이가 30자 보다 크면
			// Errors 객체에 속성변수명 "subject" 과 경고 메시지 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// int salary = dto.getSalary();
			// if( salary!=0 && (Math.log10(salary)+1) >16) {
			// 	errors.rejectValue("salary", "연봉 16자이하 입니다.");
			// }

			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils 클래스의 rejectIfEmptyOrWhitespace 메소드 호출하여
			//		BoardDTO 객체의 속성변수명 writer 이 비거나 공백으로 구성되어 있으면
			//		경고 메시지를 Errors 객체ㅇ에 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			ValidationUtils.rejectIfEmptyOrWhitespace(
				errors                    // Errors 객체
				, "jumin_no"                 // BoardDTO 객체의 속성변수명
				, "주민번호 입력요망"         // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			);
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// BoardDTO 객체의 속성변수명 "content" 저장된 데이터의 길이가 30자 보다 크면
			// Errors 객체에 속성변수명 "content" 과 경고 메시지 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			String jumin_no1 = dto.getJumin_no1();
			if( Pattern.matches("\\d{2}([0]\\d|[1][0-2])([0][1-9]|[1-2]\\d|[3][0-1])", jumin_no1)==false ) {
				errors.rejectValue("jumin_no1", "올바른 앞자리 주민등록번호를 넣어주세요. \r숫자 입력 요망!");
			};
			String jumin_no2 = dto.getJumin_no2();
			if( Pattern.matches("[1-4]\\d{6}", jumin_no2)==false ) {
				errors.rejectValue("jumin_no2", "올바른 뒷자리 주민등록번호를 넣어주세요. \r숫자 입력 요망!");
			};
			// String jumin_no = dto.getJumin_no();
			// if( jumin_no!=null && jumin_no.length() >14) {
			// 	errors.rejectValue("jumin_no", "주민번호 공백없이 13자이하 입니다.");
			// }

			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils 클래스의 rejectIfEmptyOrWhitespace 메소드 호출하여
			//		BoardDTO 객체의 속성변수명 writer 이 비거나 공백으로 구성되어 있으면
			//		경고 메시지를 Errors 객체에 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils.rejectIfEmptyOrWhitespace(
			// 	errors                    // Errors 객체
			// 	, "phone"                 // BoardDTO 객체의 속성변수명
			// 	, "전화번호 입력요망"         // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			// // );
			ValidationUtils.rejectIfEmptyOrWhitespace(
				errors                    // Errors 객체
				, "religion_code"                 // BoardDTO 객체의 속성변수명
				, "종교를 선택하여야 합니다."         // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			);



			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// ValidationUtils 클래스의 rejectIfEmptyOrWhitespace 메소드 호출하여
			//		BoardDTO 객체의 속성변수명 writer 이 비거나 공백으로 구성되어 있으면
			//		경고 메시지를 Errors 객체에 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			ValidationUtils.rejectIfEmptyOrWhitespace(
				errors                    // Errors 객체
				, "school_code"                 // BoardDTO 객체의 속성변수명
				, "학력을 선택하여야 합니다."         // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			);
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// BoardDTO 객체의 속성변수명 "pwd" 저장된 데이터가 숫자로 4자리가 아니면
			// Errors 객체에 속성변수명 "pwd" 과 경고 메시지 저장하기
			//nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
			// String mgr_emp_no = dto.getMgr_emp_no();
			// if( Pattern.matches("^[0-9]{1,9}$", mgr_emp_no)==false ) {
			// 	errors.rejectValue("mgr_emp_no", "직속상관번호 숫자 입니다. 재입력 요망");
			// }
			ValidationUtils.rejectIfEmptyOrWhitespace(
				errors                    // Errors 객체
				, "skill_code_multi"                 // BoardDTO 객체의 속성변수명
				, "기술은 하나이상 선택하여야 합니다."         // BoardDTO 객체의 속성변수명이 비거나 공백으로 구성되어 있을때 경고 문구
			);
			String xxx =dto.getStart_month();
			System.out.println("유효성 체크 Validator쪽 월 검사 값 확인=>>" + xxx  );

			String start_year = dto.getStart_year();
			if( start_year.equals("0000")) {
				errors.rejectValue("start_year", "졸업일 년도를 선택해야합니다.");
			}			
			
			String start_month = dto.getStart_month();
			if( start_month.equals("00")) {
				errors.rejectValue("start_month", "졸업일 월을 선택해야합니다.");
			}			
			
			String start_day = dto.getStart_day();
			if( start_day.equals("00")) {
				errors.rejectValue("start_day", "졸업일 일을 선택해야합니다.");
			}
			

			// int year1 = dto.getStart_year();
			// int month1 = dto.getStart_month();
			// System.out.println("유효성 체크 Validator쪽 월 검사 값 확인=>>" + month1  );
			// int date1 = dto.getStart_day();




			// String year = year1+"";
			// String month = month1+"";
			// String date = date1+"";


			// String year = Integer.toString(year1);
			// String month = Integer.toString(month1);
			// String date = Integer.toString(date1);
			
			// String year = String.valueOf(year1);
			// String month = String.valueOf(month1);
			// String date = String.valueOf(date1);
			
			String checkDateStr =  start_year+"-"+start_month+"-"+start_day;
			// String checkDateStr = "1990-02-31";
			

			System.out.println("유효성 체크 Validator쪽 날짜 검사 값 확인=>>" + checkDateStr  );
			if(checkDate(checkDateStr)==false) {
				errors.rejectValue("graduate_day", "잘못된 날짜입니다. \r날짜를 다시확인해주세요!");
			}



		}catch(Exception ex) {
			System.out.println( "BoardValidator.validate 메소드 실행 시 예외발생!" );
		}
		System.out.println( "BoardValidator.validate 메소드 유효성 통과" );

	}

	public static boolean checkDate(String checkDate) {
		try {
			SimpleDateFormat dateFormatParser = new SimpleDateFormat("yyyy-MM-dd"); //검증할 날짜 포맷 설정
			dateFormatParser.setLenient(false); //false일경우 처리시 입력한 값이 잘못된 형식일 시 오류가 발생
			dateFormatParser.parse(checkDate); //대상 값 포맷에 적용되는지 확인
			return true;
		} catch (Exception e) {
			return false;
		}
	}

    
}

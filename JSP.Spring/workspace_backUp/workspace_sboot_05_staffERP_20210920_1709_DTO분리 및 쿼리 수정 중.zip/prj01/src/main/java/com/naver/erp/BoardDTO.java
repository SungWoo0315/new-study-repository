package com.naver.erp;

import java.util.List;

public class BoardDTO {
// public class BoardVO 라고도 쓰기도 한다.  
	
	private int emp_no;
    private String emp_name;
	private int dep_no;
    private String dep_name;
    private String jikup;
    private int salary;
    private String hire_date;
    private String jumin_num;
    private String phone;
    private int mgr_emp_no;

	private String pic;

	private String depNoList;

	// --------------------------------

	private int staff_no;
	private String staff_name;
	private String jumin_no;
	private String graduate_day;

	private String sex;
	// private String religionList; // 지워야 하는지 보기 지워야함.  매퍼쪽 알리아스랑 일치해야함.
	private String religion_code;
	private String religion_name;

	private String school_code;
	private String school_name;
	
	// private String up_del_skill_code;

//	private String skill_code;
	private String skill_code;
	private String skill_name;

	private List<String> skill_code_multi;

	private String is_del;


	public int getEmp_no() {
		return emp_no;
	}
	public void setEmp_no(int emp_no) {
		this.emp_no = emp_no;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getDep_name() {
		return dep_name;
	}
	public void setDep_name(String dep_name) {
		this.dep_name = dep_name;
	}
	public String getJikup() {
		return jikup;
	}
	public void setJikup(String jikup) {
		this.jikup = jikup;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getHire_date() {
		return hire_date;
	}
	public void setHire_date(String hire_date) {
		this.hire_date = hire_date;
	}
	public String getJumin_num() {
		return jumin_num;
	}
	public void setJumin_num(String jumin_num) {
		this.jumin_num = jumin_num;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getMgr_emp_no() {
		return mgr_emp_no;
	}
	public void setMgr_emp_no(int mgr_emp_no) {
		this.mgr_emp_no = mgr_emp_no;
	}
	public int getDep_no() {
		return dep_no;
	}
	public void setDep_no(int dep_no) {
		this.dep_no = dep_no;
	}
	
	
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	
	
	
	public String getDepNoList() {
		return depNoList;
	}
	public void setDepNoList(String depNoList) {
		this.depNoList = depNoList;
	}
	
	
	
	public String getIs_del() {
		return is_del;
	}
	public void setIs_del(String is_del) {
		this.is_del = is_del;
	}
	
	
	
	
	
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	// public String getReligionList() {
	// 	return religionList;
	// }
	// public void setReligionList(String religionList) {
	// 	this.religionList = religionList;
	// }
	public String getReligion_code() {
		return religion_code;
	}
	public void setReligion_code(String religion_code) {
		this.religion_code = religion_code;
	}
	public String getReligion_name() {
		return religion_name;
	}
	public void setReligion_name(String religion_name) {
		this.religion_name = religion_name;
	}
	public String getSchool_code() {
		return school_code;
	}
	public void setSchool_code(String school_code) {
		this.school_code = school_code;
	}
	public String getSchool_name() {
		return school_name;
	}
	public void setSchool_name(String school_name) {
		this.school_name = school_name;
	}
	
	
//	public String getSkill_code() {
//		return skill_code;
//	}
//	public void setSkill_code(String skill_code) {
//		this.skill_code = skill_code;
//	}
	
	
	

	public int getStaff_no() {
		return staff_no;
	}
	public void setStaff_no(int staff_no) {
		this.staff_no = staff_no;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getJumin_no() {
		return jumin_no;
	}
	public void setJumin_no(String jumin_no) {
		this.jumin_no = jumin_no;
	}
	public String getGraduate_day() {
		return graduate_day;
	}
	public void setGraduate_day(String graduate_day) {
		this.graduate_day = graduate_day;
	}
	// public String getUp_del_skill_code() {
	// 	return up_del_skill_code;
	// }
	// public void setUp_del_skill_code(String up_del_skill_code) {
	// 	this.up_del_skill_code = up_del_skill_code;
	// }
	
	
	
	public String getSkill_code() {
		return skill_code;
	}
	public void setSkill_code(String skill_code) {
		this.skill_code = skill_code;
	}
	public String getSkill_name() {
		return skill_name;
	}
	public void setSkill_name(String skill_name) {
		this.skill_name = skill_name;
	}
	
	
	
	public List<String> getSkill_code_multi() {
		return skill_code_multi;
	}
	public void setSkill_code_multi(List<String> skill_code_multi) {
		this.skill_code_multi = skill_code_multi;
	}
	
	
	
	
	
	


	
	
	
	
	
	
	
	
	
	
	
	
    
    
    
    
    
    
}

package com.naver.erp;

public class BoardDTO {
// public class BoardVO 라고도 쓰기도 한다.  
	
	private int emp_no;
    private String emp_name;
	private int dep_no;
    private String dep_name;
    private String jikup;
    private int salary;
    private String hire_date;
    private String jumin_num;
    private String phone;
    private int mgr_emp_no;

	private String pic;

	private String depNoList;
	
	private String is_del;


	public int getEmp_no() {
		return emp_no;
	}
	public void setEmp_no(int emp_no) {
		this.emp_no = emp_no;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getDep_name() {
		return dep_name;
	}
	public void setDep_name(String dep_name) {
		this.dep_name = dep_name;
	}
	public String getJikup() {
		return jikup;
	}
	public void setJikup(String jikup) {
		this.jikup = jikup;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getHire_date() {
		return hire_date;
	}
	public void setHire_date(String hire_date) {
		this.hire_date = hire_date;
	}
	public String getJumin_num() {
		return jumin_num;
	}
	public void setJumin_num(String jumin_num) {
		this.jumin_num = jumin_num;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getMgr_emp_no() {
		return mgr_emp_no;
	}
	public void setMgr_emp_no(int mgr_emp_no) {
		this.mgr_emp_no = mgr_emp_no;
	}
	public int getDep_no() {
		return dep_no;
	}
	public void setDep_no(int dep_no) {
		this.dep_no = dep_no;
	}
	
	
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	
	
	
	public String getDepNoList() {
		return depNoList;
	}
	public void setDepNoList(String depNoList) {
		this.depNoList = depNoList;
	}
	
	
	
	public String getIs_del() {
		return is_del;
	}
	public void setIs_del(String is_del) {
		this.is_del = is_del;
	}
	
	
	
	
	
	
    
    
    
    
    
    
}

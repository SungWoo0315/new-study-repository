package com.naver.erp;


public interface Info { 
	
    // <주의> 경로가 문자열이므로 \ 를 \\ 로 써야함. \\ 대신에 / 쓰지 말것.
	public static String board_pic_dir 
		= "C:\\Users\\SungWoo\\Desktop\\GitHub\\new-study-repository\\JSP.Spring\\workspace_sboot_01\\prj01\\src\\main\\resources\\static\\resources\\img\\";


	public static String naverPath = "naver/";
	

}

